package com.freefire3d;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Loop principal: atualiza o jogo e desenha tudo. */
public class GameRenderer implements GLSurfaceView.Renderer {
    final Game game;
    final Hud hud;
    final Input in;
    long last = 0;
    final float[] m = new float[16];
    final Entity lobbyEnt = new Entity();

    public GameRenderer(Game game, Hud hud, Input in) {
        this.game = game; this.hud = hud; this.in = in;
        lobbyEnt.shirt = 0x2563eb;
        lobbyEnt.slot[0] = Wpn.AK47;
        lobbyEnt.cur = 0;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        Gfx.init();
        Models.init();
        Batch.reuploadAll();
        last = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        Gfx.resize(width, height);
        hud.layout(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = (now - last) / 1e9f;
        last = now;
        if (dt > 0.05f) dt = 0.05f;
        if (dt <= 0f) dt = 0.016f;
        game.update(dt);

        if (game.phase == Game.LOBBY) drawLobby();
        else drawGame();
    }

    void identity() { Matrix.setIdentityM(m, 0); }

    // ------------------------------------------------------------------ lobby

    void drawLobby() {
        GLES20.glClearColor(0.07f, 0.09f, 0.22f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Gfx.begin2D();
        hud.drawLobbyBg();
        Gfx.fogR = 0.2f; Gfx.fogG = 0.2f; Gfx.fogB = 0.35f;
        Gfx.begin3D();
        Gfx.setCamera(game.cx, game.cy, game.cz, game.tx, game.ty, game.tz, game.fov);
        identity();
        Gfx.drawUnit(m, -1.1f, -0.06f, 0, 1.8f, 0.12f, 1.8f, 0x334155, 1f);
        Gfx.drawUnit(m, -1.1f, -0.01f, 0, 1.5f, 0.04f, 1.5f, 0xf97316, 1f);
        Matrix.setIdentityM(m, 0);
        Matrix.translateM(m, 0, -1.1f, 0, 0);
        Matrix.rotateM(m, 0, (float) Math.sin(game.lobbyT * 0.7f) * 28f, 0, 1, 0);
        Models.human(m, lobbyEnt, true);
        Gfx.begin2D();
        hud.drawLobby(game, in);
    }

    // ------------------------------------------------------------------- jogo

    void drawGame() {
        GLES20.glClearColor(0.56f, 0.79f, 0.96f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Gfx.fogR = 0.56f; Gfx.fogG = 0.79f; Gfx.fogB = 0.96f;
        Gfx.begin3D();
        Gfx.setCamera(game.cx, game.cy, game.cz, game.tx, game.ty, game.tz, game.fov);

        identity();
        Gfx.draw(game.world.batch, m, 1, 1, 1, 1);

        drawLoot();
        drawEntities();
        drawTracers();

        float pdx = game.planeX - game.cx, pdz = game.planeZ - game.cz;
        if (pdx * pdx + pdz * pdz < 260f * 260f) {
            Matrix.setIdentityM(m, 0);
            Matrix.translateM(m, 0, game.planeX, Game.PLANE_Y, game.planeZ);
            float yaw = (float) Math.atan2(game.dirX, -game.dirZ);
            Matrix.rotateM(m, 0, (float) (-yaw * 180.0 / Math.PI), 0, 1, 0);
            Models.plane(m);
        }

        drawGas();

        Entity p = game.pl;
        if (game.phase == Game.PLAY && p != null && p.alive && !game.thirdPerson) {
            Wpn w = p.gun();
            if (w != null && !w.melee && !w.sniper) {
                Gfx.beginViewSpace();
                Matrix.setIdentityM(m, 0);
                float kick = Math.max(0f, p.fireCd) * 0.25f;
                Matrix.translateM(m, 0, 0.17f, -0.2f, -0.42f + kick);
                Models.gun(m, p.slot[p.cur], 1.0f);
            }
        }

        Gfx.begin2D();
        hud.draw(game, in);
    }

    void drawEntities() {
        for (int i = 0; i < game.ents.size(); i++) {
            Entity e = game.ents.get(i);
            if (!e.active) continue;
            if (e == game.pl) {
                if (game.phase == Game.PLANE) continue;
                if (game.phase == Game.PLAY && !game.thirdPerson && e.alive) continue;
            }
            float dx = e.x - game.cx, dz = e.z - game.cz;
            if (dx * dx + dz * dz > 150f * 150f) continue;
            Matrix.setIdentityM(m, 0);
            Matrix.translateM(m, 0, e.x, e.y, e.z);
            Matrix.rotateM(m, 0, (float) (-e.yaw * 180.0 / Math.PI), 0, 1, 0);
            Models.human(m, e, true);
        }
    }

    void drawLoot() {
        float t = game.time;
        for (int i = 0; i < game.loot.size(); i++) {
            Loot l = game.loot.get(i);
            float dx = l.x - game.cx, dz = l.z - game.cz;
            if (dx * dx + dz * dz > 75f * 75f) continue;
            float bob = 0.55f + 0.1f * (float) Math.sin(t * 2f + l.x);
            Matrix.setIdentityM(m, 0);
            Matrix.translateM(m, 0, l.x, l.y + bob, l.z);
            Matrix.rotateM(m, 0, t * 70f, 0, 1, 0);
            if (l.type == Loot.GUN) {
                Models.gun(m, l.gun, 1.3f);
            } else if (l.type == Loot.MEDKIT) {
                Gfx.drawUnit(m, 0, 0, 0, 0.5f, 0.35f, 0.3f, 0xf8fafc, 1f);
                Gfx.drawUnit(m, 0, 0, 0, 0.3f, 0.08f, 0.32f, 0xdc2626, 1f);
                Gfx.drawUnit(m, 0, 0, 0, 0.08f, 0.3f, 0.32f, 0xdc2626, 1f);
            } else {
                Gfx.drawUnit(m, 0, 0, 0, 0.5f, 0.55f, 0.25f, 0x38bdf8, 1f);
                Gfx.drawUnit(m, 0, 0.1f, 0, 0.4f, 0.1f, 0.27f, 0x0ea5e9, 1f);
            }
            identity();
            Gfx.drawUnit(m, l.x, l.y + 1.6f, l.z, 0.07f, 3.2f, 0.07f, l.color(), 0.55f);
        }
    }

    void drawTracers() {
        for (int i = 0; i < game.tracers.size(); i++) {
            float[] t = game.tracers.get(i);
            float dx = t[3] - t[0], dy = t[4] - t[1], dz = t[5] - t[2];
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1f) continue;
            float hor = (float) Math.sqrt(dx * dx + dz * dz);
            float yaw = (float) Math.atan2(dx, -dz);
            float pit = (float) Math.atan2(dy, hor);
            Matrix.setIdentityM(m, 0);
            Matrix.translateM(m, 0, (t[0] + t[3]) / 2f, (t[1] + t[4]) / 2f, (t[2] + t[5]) / 2f);
            Matrix.rotateM(m, 0, (float) (-yaw * 180.0 / Math.PI), 0, 1, 0);
            Matrix.rotateM(m, 0, (float) (pit * 180.0 / Math.PI), 1, 0, 0);
            Gfx.drawUnit(m, 0, 0, 0, 0.04f, 0.04f, len, 0xfff1a8, 1f);
        }
    }

    void drawGas() {
        if (!game.gasOn) return;
        GLES20.glDepthMask(false);
        int n = 64;
        float R = game.gasR;
        float segW = (float) (2.0 * Math.PI * R / n) * 1.06f;
        for (int k = 0; k < n; k++) {
            float a = (float) (k * 2.0 * Math.PI / n);
            float x = game.gasX + (float) Math.cos(a) * R;
            float z = game.gasZ + (float) Math.sin(a) * R;
            float dx = x - game.cx, dz = z - game.cz;
            if (dx * dx + dz * dz > 260f * 260f) continue;
            Matrix.setIdentityM(m, 0);
            Matrix.translateM(m, 0, x, 0, z);
            Matrix.rotateM(m, 0, (float) (-(a * 180.0 / Math.PI + 90.0)), 0, 1, 0);
            Gfx.drawUnit(m, 0, 30f, 0, segW, 60f, 0.4f, 0x8b5cf6, 0.28f);
        }
        GLES20.glDepthMask(true);
    }
}
