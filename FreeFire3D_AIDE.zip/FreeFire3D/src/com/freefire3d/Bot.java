package com.freefire3d;

public class Bot extends Entity {
    public float jumpAt, tx, tz, thinkT, stuckT, lx, lz, strafeT, strafeDir = 1f;
    public float reactT, burstT = 1f, pauseT = 0f, alertT, wayT;
    public Entity target;
    public Loot lootT;
}
