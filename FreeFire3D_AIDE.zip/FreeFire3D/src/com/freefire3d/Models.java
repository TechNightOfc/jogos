package com.freefire3d;

import android.opengl.Matrix;

/** Modelos voxel: humano, armas, aviao. */
public class Models {
    static Batch head, hair, face, torso, arm, hand, leg;
    static float[] m = new float[16], m2 = new float[16];

    static void init() {
        if (head != null) return;
        head = new Batch(); head.box(0, 1.65f, 0, 0.3f, 0.3f, 0.3f, 0xf1c27d);
        hair = new Batch();
        hair.box(0, 1.84f, 0.01f, 0.33f, 0.1f, 0.33f, 0x2b1b12);
        hair.box(0, 1.70f, 0.14f, 0.32f, 0.22f, 0.06f, 0x2b1b12);
        face = new Batch();
        face.box(-0.07f, 1.67f, -0.152f, 0.05f, 0.05f, 0.02f, 0x111111);
        face.box(0.07f, 1.67f, -0.152f, 0.05f, 0.05f, 0.02f, 0x111111);
        torso = new Batch(); torso.box(0, 1.15f, 0, 0.52f, 0.7f, 0.3f, 0xffffff);
        arm = new Batch(); arm.box(0, -0.28f, 0, 0.16f, 0.58f, 0.18f, 0xffffff);
        hand = new Batch(); hand.box(0, -0.62f, 0, 0.14f, 0.12f, 0.16f, 0xf1c27d);
        leg = new Batch();
        leg.box(0, -0.37f, 0, 0.22f, 0.74f, 0.24f, 0x374151);
        leg.box(0, -0.77f, -0.03f, 0.24f, 0.1f, 0.3f, 0x111111);
    }

    static float r(int c) { return ((c >> 16) & 255) / 255f; }
    static float g(int c) { return ((c >> 8) & 255) / 255f; }
    static float b(int c) { return (c & 255) / 255f; }

    /** base = translate(x,y,z) * rotateY(-yaw). */
    public static void human(float[] base, Entity e, boolean showGun) {
        init();
        float[] bm = new float[16];
        System.arraycopy(base, 0, bm, 0, 16);
        if (!e.alive) {
            Matrix.translateM(bm, 0, 0, 0.25f, 0);
            Matrix.rotateM(bm, 0, 90f, 1f, 0f, 0f);
        }
        if (e.crouch && e.alive) {
            Matrix.translateM(bm, 0, 0, -0.35f, 0);
        }
        Wpn w = e.gun();
        boolean armed = e.alive && w != null && !w.melee;
        float sw = e.alive ? (float) Math.sin(e.walk) * Math.min(1f, e.speed / 4f) * 38f : 0f;

        Gfx.draw(head, bm, 1, 1, 1, 1);
        Gfx.draw(hair, bm, 1, 1, 1, 1);
        Gfx.draw(face, bm, 1, 1, 1, 1);
        Gfx.draw(torso, bm, r(e.shirt), g(e.shirt), b(e.shirt), 1);

        // pernas
        for (int s = -1; s <= 1; s += 2) {
            System.arraycopy(bm, 0, m, 0, 16);
            Matrix.translateM(m, 0, 0.13f * s, 0.8f, 0);
            Matrix.rotateM(m, 0, sw * s, 1, 0, 0);
            Gfx.draw(leg, m, 1, 1, 1, 1);
        }
        // bracos
        for (int s = -1; s <= 1; s += 2) {
            System.arraycopy(bm, 0, m, 0, 16);
            Matrix.translateM(m, 0, 0.35f * s, 1.46f, 0);
            float ang = armed ? 78f : -sw * s * 0.8f;
            Matrix.rotateM(m, 0, ang, 1, 0, 0);
            Gfx.draw(arm, m, r(e.shirt), g(e.shirt), b(e.shirt), 1);
            Gfx.draw(hand, m, 1, 1, 1, 1);
        }
        if (showGun && e.alive && w != null) {
            System.arraycopy(bm, 0, m2, 0, 16);
            if (w.melee) {
                Matrix.translateM(m2, 0, 0.42f, 1.0f, -0.1f);
            } else {
                Matrix.translateM(m2, 0, 0.12f, 1.2f, -0.28f);
            }
            gun(m2, e.slot[e.cur], 1f);
        }
        // paraquedas
        if (e.chute && e.alive) {
            System.arraycopy(base, 0, m2, 0, 16);
            Gfx.drawUnit(m2, 0, 4.4f, 0, 5.2f, 0.25f, 5.2f, 0xef4444, 1f);
            Gfx.drawUnit(m2, 0, 4.5f, 0, 2.6f, 0.3f, 5.3f, 0xffffff, 1f);
            Gfx.drawUnit(m2, -0.2f, 2.3f, 0, 0.03f, 4.2f, 0.03f, 0xdddddd, 1f);
            Gfx.drawUnit(m2, 0.2f, 2.3f, 0, 0.03f, 4.2f, 0.03f, 0xdddddd, 1f);
        }
    }

    /** Arma apontando para -Z, origem na empunhadura. */
    public static void gun(float[] base, int wi, float sc) {
        if (wi < 0) return;
        Wpn w = Wpn.ALL[wi];
        float[] bm = new float[16];
        System.arraycopy(base, 0, bm, 0, 16);
        Matrix.scaleM(bm, 0, sc, sc, sc);
        if (w.melee) {
            Gfx.drawUnit(bm, 0, 0, -0.55f, 0.025f, 0.06f, 0.9f, 0xe5e7eb, 1f);
            Gfx.drawUnit(bm, 0, 0, -0.1f, 0.12f, 0.12f, 0.03f, 0xfacc15, 1f);
            Gfx.drawUnit(bm, 0, 0, 0.05f, 0.04f, 0.04f, 0.25f, 0x7f1d1d, 1f);
            return;
        }
        float L = w.len;
        Gfx.drawUnit(bm, 0, 0, -0.15f * L, 0.07f, 0.11f, 0.45f * L, w.color, 1f);
        Gfx.drawUnit(bm, 0, 0.015f, -0.515f * L, 0.035f, 0.035f, 0.28f * L, 0x222222, 1f);
        Gfx.drawUnit(bm, 0, -0.01f, 0.175f * L, 0.05f, 0.09f, 0.2f * L, 0x3b2a1a, 1f);
        Gfx.drawUnit(bm, 0, -0.11f, 0.0f, 0.05f, 0.12f, 0.06f, 0x222222, 1f);
        Gfx.drawUnit(bm, 0, -0.12f, -0.12f * L, 0.05f, 0.14f, 0.07f, 0x1f2937, 1f);
        if (w.sniper) Gfx.drawUnit(bm, 0, 0.09f, -0.12f * L, 0.05f, 0.05f, 0.3f * L * 0.6f, 0x111111, 1f);
        if (wi == Wpn.DUAL) Gfx.drawUnit(bm, 0.12f, 0, -0.15f * L, 0.07f, 0.11f, 0.45f * L, w.color, 1f);
    }

    public static void plane(float[] base) {
        Gfx.drawUnit(base, 0, 0, 0, 3.2f, 3f, 16f, 0xf1f5f9, 1f);
        Gfx.drawUnit(base, 0, 0, -8.6f, 2.2f, 2.2f, 2.5f, 0xef4444, 1f);
        Gfx.drawUnit(base, 0, -0.2f, 0.5f, 22f, 0.35f, 3.4f, 0xe2e8f0, 1f);
        Gfx.drawUnit(base, 0, 0.1f, 7.5f, 7f, 0.25f, 2f, 0xe2e8f0, 1f);
        Gfx.drawUnit(base, 0, 2.2f, 7.5f, 0.3f, 3f, 2.4f, 0xef4444, 1f);
        Gfx.drawUnit(base, 0, 0.9f, -4.5f, 2.4f, 0.9f, 2.4f, 0x38bdf8, 1f);
    }
}
