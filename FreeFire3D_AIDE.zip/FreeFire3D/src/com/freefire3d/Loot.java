package com.freefire3d;

public class Loot {
    public static final int GUN = 0, MEDKIT = 1, VEST = 2;
    public int type, gun;
    public float x, y, z;

    public Loot(int type, int gun, float x, float z) {
        this.type = type; this.gun = gun; this.x = x; this.z = z;
    }

    public String label() {
        if (type == GUN) return Wpn.ALL[gun].name;
        return type == MEDKIT ? "Kit Medico" : "Colete";
    }

    public int color() {
        if (type == MEDKIT) return 0x22c55e;
        if (type == VEST) return 0x38bdf8;
        Wpn w = Wpn.ALL[gun];
        return w.sniper ? 0xf97316 : 0xfacc15;
    }
}
