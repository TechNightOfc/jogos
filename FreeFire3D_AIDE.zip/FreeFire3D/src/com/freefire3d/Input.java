package com.freefire3d;

/** Ponte entre o toque (thread de UI) e o jogo (thread GL). */
public class Input {
    public static final int B_FIRE = 0, B_AIM = 1, B_JUMP = 2, B_CROUCH = 3, B_RELOAD = 4,
            B_MEDKIT = 5, B_PICKUP = 6, B_S0 = 7, B_S1 = 8, B_S2 = 9, B_START = 10,
            B_PLANEJUMP = 11, B_LOBBY = 12;

    public volatile float moveX, moveY;
    public volatile boolean fire;
    private float lookDX, lookDY;
    private int pressed;

    public synchronized void addLook(float dx, float dy) { lookDX += dx; lookDY += dy; }

    public synchronized float[] takeLook() {
        float[] r = { lookDX, lookDY };
        lookDX = 0; lookDY = 0;
        return r;
    }

    public synchronized void press(int id) { pressed |= (1 << id); }

    public synchronized boolean take(int id) {
        boolean b = (pressed & (1 << id)) != 0;
        pressed &= ~(1 << id);
        return b;
    }

    public synchronized void clearPresses() { pressed = 0; }
}
