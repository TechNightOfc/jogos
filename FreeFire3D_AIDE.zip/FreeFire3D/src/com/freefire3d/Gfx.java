package com.freefire3d;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.HashMap;

/** Tudo que mexe com OpenGL ES 2.0: shaders, 3D, 2D (HUD) e texto. */
public class Gfx {
    static int p3, pf, pt;
    static int aPos, aNor, aCol, uMVP, uModel, uTint, uCam, uFog, uAlpha;
    static int fPos, fProj, fColor;
    static int tPos, tUV, tProj, tTex, tAlpha;

    public static int W = 1, H = 1;
    public static float[] proj = new float[16], view = new float[16], vp = new float[16];
    public static float[] proj2d = new float[16];
    static float[] mvp = new float[16], tmp = new float[16];
    static float camX, camY, camZ;
    public static float fogR = 0.56f, fogG = 0.79f, fogB = 0.96f;
    public static Batch UNIT;

    static FloatBuffer fb = ByteBuffer.allocateDirect(4 * 2048).order(ByteOrder.nativeOrder()).asFloatBuffer();
    static float[] fa = new float[2048];

    static final String V3 =
        "attribute vec3 aPos; attribute vec3 aNor; attribute vec3 aCol;" +
        "uniform mat4 uMVP; uniform mat4 uModel; uniform vec3 uTint; uniform vec3 uCam;" +
        "varying vec3 vCol; varying float vFog;" +
        "void main(){" +
        " vec3 n = normalize((uModel*vec4(aNor,0.0)).xyz);" +
        " float l = 0.50 + 0.50*max(dot(n, normalize(vec3(0.45,0.85,0.30))),0.0);" +
        " vec4 wp = uModel*vec4(aPos,1.0);" +
        " vCol = aCol*uTint*l;" +
        " vFog = clamp(length(wp.xyz-uCam)/170.0,0.0,1.0);" +
        " gl_Position = uMVP*vec4(aPos,1.0);}";
    static final String F3 =
        "precision mediump float; uniform vec3 uFog; uniform float uAlpha;" +
        "varying vec3 vCol; varying float vFog;" +
        "void main(){ gl_FragColor = vec4(mix(vCol,uFog,vFog*vFog), uAlpha);}";

    static final String VF =
        "attribute vec2 aPos; uniform mat4 uProj;" +
        "void main(){ gl_Position = uProj*vec4(aPos,0.0,1.0);}";
    static final String FF =
        "precision mediump float; uniform vec4 uColor;" +
        "void main(){ gl_FragColor = vec4(uColor.rgb*uColor.a, uColor.a);}";

    static final String VT =
        "attribute vec2 aPos; attribute vec2 aUV; uniform mat4 uProj; varying vec2 vUV;" +
        "void main(){ vUV = aUV; gl_Position = uProj*vec4(aPos,0.0,1.0);}";
    static final String FT =
        "precision mediump float; uniform sampler2D uTex; uniform float uAlpha; varying vec2 vUV;" +
        "void main(){ gl_FragColor = texture2D(uTex,vUV)*uAlpha;}";

    static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    static int program(String v, String f) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f));
        GLES20.glLinkProgram(p);
        return p;
    }

    public static void init() {
        p3 = program(V3, F3);
        aPos = GLES20.glGetAttribLocation(p3, "aPos");
        aNor = GLES20.glGetAttribLocation(p3, "aNor");
        aCol = GLES20.glGetAttribLocation(p3, "aCol");
        uMVP = GLES20.glGetUniformLocation(p3, "uMVP");
        uModel = GLES20.glGetUniformLocation(p3, "uModel");
        uTint = GLES20.glGetUniformLocation(p3, "uTint");
        uCam = GLES20.glGetUniformLocation(p3, "uCam");
        uFog = GLES20.glGetUniformLocation(p3, "uFog");
        uAlpha = GLES20.glGetUniformLocation(p3, "uAlpha");

        pf = program(VF, FF);
        fPos = GLES20.glGetAttribLocation(pf, "aPos");
        fProj = GLES20.glGetUniformLocation(pf, "uProj");
        fColor = GLES20.glGetUniformLocation(pf, "uColor");

        pt = program(VT, FT);
        tPos = GLES20.glGetAttribLocation(pt, "aPos");
        tUV = GLES20.glGetAttribLocation(pt, "aUV");
        tProj = GLES20.glGetUniformLocation(pt, "uProj");
        tTex = GLES20.glGetUniformLocation(pt, "uTex");
        tAlpha = GLES20.glGetUniformLocation(pt, "uAlpha");

        if (UNIT == null) { UNIT = new Batch(); UNIT.box(0, 0, 0, 1, 1, 1, 0xffffff); }
        TEX.clear();   // texturas antigas morreram junto com o contexto
        GLES20.glDisable(GLES20.GL_CULL_FACE);
    }

    public static void resize(int w, int h) {
        W = w; H = h;
        GLES20.glViewport(0, 0, w, h);
        Matrix.orthoM(proj2d, 0, 0, w, h, 0, -1, 1);
    }

    // ------------------------------------------------------------------ 3D

    public static void begin3D() {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthMask(true);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(p3);
        GLES20.glUniform3f(uFog, fogR, fogG, fogB);
    }

    public static void setCamera(float ex, float ey, float ez, float tx, float ty, float tz, float fov) {
        camX = ex; camY = ey; camZ = ez;
        float aspect = (float) W / (float) H;
        Matrix.perspectiveM(proj, 0, fov, aspect, 0.12f, 300f);
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0f, 1f, 0f);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        GLES20.glUniform3f(uCam, ex, ey, ez);
    }

    /** Desenha no espaco da camera (arma em primeira pessoa). */
    public static void beginViewSpace() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);
        System.arraycopy(proj, 0, vp, 0, 16);
        GLES20.glUniform3f(uCam, 0, 0, 0);
    }

    public static void draw(Batch b, float[] model, float r, float g, float bl, float alpha) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0);
        GLES20.glUniform3f(uTint, r, g, bl);
        GLES20.glUniform1f(uAlpha, alpha);
        b.draw(aPos, aNor, aCol);
    }

    public static void drawUnit(float[] base, float x, float y, float z,
                                float sx, float sy, float sz, int rgb, float alpha) {
        System.arraycopy(base, 0, tmp, 0, 16);
        Matrix.translateM(tmp, 0, x, y, z);
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        draw(UNIT, tmp, ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, alpha);
    }

    // ------------------------------------------------------------------ 2D

    public static void begin2D() {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }

    static void setColor(int rgb, float a) {
        GLES20.glUniform4f(fColor, ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a);
    }

    static void flat(int mode, int count) {
        fb.clear();
        fb.put(fa, 0, count * 2);
        fb.position(0);
        GLES20.glEnableVertexAttribArray(fPos);
        GLES20.glVertexAttribPointer(fPos, 2, GLES20.GL_FLOAT, false, 8, fb);
        GLES20.glDrawArrays(mode, 0, count);
        GLES20.glDisableVertexAttribArray(fPos);
    }

    public static void rect(float x, float y, float w, float h, int rgb, float a) {
        GLES20.glUseProgram(pf);
        GLES20.glUniformMatrix4fv(fProj, 1, false, proj2d, 0);
        setColor(rgb, a);
        fa[0] = x; fa[1] = y; fa[2] = x + w; fa[3] = y;
        fa[4] = x; fa[5] = y + h; fa[6] = x + w; fa[7] = y + h;
        flat(GLES20.GL_TRIANGLE_STRIP, 4);
    }

    public static void circle(float cx, float cy, float r, int rgb, float a) {
        GLES20.glUseProgram(pf);
        GLES20.glUniformMatrix4fv(fProj, 1, false, proj2d, 0);
        setColor(rgb, a);
        int seg = 36;
        fa[0] = cx; fa[1] = cy;
        for (int i = 0; i <= seg; i++) {
            double an = i * Math.PI * 2 / seg;
            fa[2 + i * 2] = cx + (float) Math.cos(an) * r;
            fa[3 + i * 2] = cy + (float) Math.sin(an) * r;
        }
        flat(GLES20.GL_TRIANGLE_FAN, seg + 2);
    }

    public static void ring(float cx, float cy, float rin, float rout, int rgb, float a) {
        GLES20.glUseProgram(pf);
        GLES20.glUniformMatrix4fv(fProj, 1, false, proj2d, 0);
        setColor(rgb, a);
        int seg = 48;
        for (int i = 0; i <= seg; i++) {
            double an = i * Math.PI * 2 / seg;
            float c = (float) Math.cos(an), s = (float) Math.sin(an);
            fa[i * 4] = cx + c * rin;
            fa[i * 4 + 1] = cy + s * rin;
            fa[i * 4 + 2] = cx + c * rout;
            fa[i * 4 + 3] = cy + s * rout;
        }
        flat(GLES20.GL_TRIANGLE_STRIP, (seg + 1) * 2);
    }

    public static void line(float x1, float y1, float x2, float y2, float th, int rgb, float a) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return;
        float nx = -dy / len * th / 2, ny = dx / len * th / 2;
        GLES20.glUseProgram(pf);
        GLES20.glUniformMatrix4fv(fProj, 1, false, proj2d, 0);
        setColor(rgb, a);
        fa[0] = x1 - nx; fa[1] = y1 - ny; fa[2] = x1 + nx; fa[3] = y1 + ny;
        fa[4] = x2 - nx; fa[5] = y2 - ny; fa[6] = x2 + nx; fa[7] = y2 + ny;
        flat(GLES20.GL_TRIANGLE_STRIP, 4);
    }

    // ---------------------------------------------------------------- texto

    static final HashMap<String, int[]> TEX = new HashMap<String, int[]>();

    static int[] texFor(String s, float size, int color) {
        String k = s + "|" + (int) size + "|" + color;
        int[] t = TEX.get(k);
        if (t != null) return t;
        if (TEX.size() > 220) {
            for (int[] o : TEX.values()) GLES20.glDeleteTextures(1, new int[] { o[0] }, 0);
            TEX.clear();
        }
        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setTextSize(size);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        int pad = (int) (size * 0.2f) + 2;
        int bw = (int) p.measureText(s) + pad * 2;
        int bh = (int) (size * 1.3f) + pad * 2;
        Bitmap bmp = Bitmap.createBitmap(Math.max(bw, 2), Math.max(bh, 2), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float base = pad + size;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(size * 0.16f);
        p.setColor(0xFF000000);
        c.drawText(s, pad, base, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000 | color);
        c.drawText(s, pad, base, p);
        int[] id = new int[1];
        GLES20.glGenTextures(1, id, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
        t = new int[] { id[0], bmp.getWidth(), bmp.getHeight() };
        bmp.recycle();
        TEX.put(k, t);
        return t;
    }

    /** align: 0 esquerda, 1 centro, 2 direita. (x,y) = ponto de ancoragem, y no meio da linha. */
    public static void text(String s, float x, float y, float size, int rgb, int align, float alpha) {
        if (s == null || s.length() == 0) return;
        int[] t = texFor(s, size, rgb);
        float w = t[1], h = t[2];
        float x0 = align == 0 ? x : (align == 1 ? x - w / 2 : x - w);
        float y0 = y - h / 2;
        GLES20.glUseProgram(pt);
        GLES20.glUniformMatrix4fv(tProj, 1, false, proj2d, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0]);
        GLES20.glUniform1i(tTex, 0);
        GLES20.glUniform1f(tAlpha, alpha);
        fa[0] = x0;     fa[1] = y0;     fa[2] = 0; fa[3] = 0;
        fa[4] = x0 + w; fa[5] = y0;     fa[6] = 1; fa[7] = 0;
        fa[8] = x0;     fa[9] = y0 + h; fa[10] = 0; fa[11] = 1;
        fa[12] = x0 + w; fa[13] = y0 + h; fa[14] = 1; fa[15] = 1;
        fb.clear();
        fb.put(fa, 0, 16);
        fb.position(0);
        GLES20.glEnableVertexAttribArray(tPos);
        GLES20.glVertexAttribPointer(tPos, 2, GLES20.GL_FLOAT, false, 16, fb);
        fb.position(2);
        GLES20.glEnableVertexAttribArray(tUV);
        GLES20.glVertexAttribPointer(tUV, 2, GLES20.GL_FLOAT, false, 16, fb);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(tPos);
        GLES20.glDisableVertexAttribArray(tUV);
        fb.position(0);
    }
}
