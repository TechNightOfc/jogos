package com.freefire3d;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    GameView view;
    Input in;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        in = new Input();
        World world = new World();
        Game game = new Game(world, in);
        Hud hud = new Hud();
        view = new GameView(this, game, hud, in);
        setContentView(view);
        hideBars();
    }

    void hideBars() {
        if (android.os.Build.VERSION.SDK_INT >= 19 && view != null) {
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) hideBars();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (view != null) view.onPause();
        if (in != null) { in.fire = false; in.moveX = 0; in.moveY = 0; }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (view != null) view.onResume();
    }
}
