package com.freefire3d;

import java.util.ArrayList;
import java.util.Random;

/** Regras do jogo: aviao, queda, tiros, bots, zona, loot. Roda na thread GL. */
public class Game {
    public static final int LOBBY = 0, PLANE = 1, FALL = 2, PLAY = 3, DEAD = 4, WIN = 5;
    public static final float PLANE_Y = 110f, PLANE_SPD = 24f;

    public static class Feed { public String s; public float t = 5f; }

    public volatile int phase = LOBBY;
    public final World world;
    public final Input in;
    public final ArrayList<Entity> ents = new ArrayList<Entity>();
    public final ArrayList<Bot> bots = new ArrayList<Bot>();
    public final ArrayList<Loot> loot = new ArrayList<Loot>();
    public final ArrayList<float[]> tracers = new ArrayList<float[]>();
    public final ArrayList<Feed> feed = new ArrayList<Feed>();
    final Random rnd = new Random();
    public Entity pl;

    public float planeX, planeZ, dirX, dirZ, planeT, planeDur;
    public boolean gasOn, gasShrink;
    public float gasX, gasZ, gasR, gasT, gFX, gFZ, gFR, gTX, gTZ, gTR;
    public int gasStage;
    static final float[] GF = { 0.62f, 0.60f, 0.55f, 0.50f, 0.35f };
    static final float[] GWAIT = { 50, 35, 30, 25, 20 };
    static final float[] GSHR = { 40, 30, 25, 20, 15 };
    static final float[] GDMG = { 1.5f, 3f, 5f, 8f, 12f };

    public float hurt, hitMark, time, lobbyT;
    public boolean hitHead, aim;
    public int rank, aliveCount;
    public Loot near;

    public float cx, cy, cz, tx, ty, tz, fov = 65f;
    public boolean thirdPerson = true;

    static final String[] NAMES = { "Naruto", "Kira", "Shadow", "Lobo", "Tigre", "Fenix", "Raio",
        "Falcao", "Ninja", "Viper", "Cobra", "Sniper_X", "Zeus", "Hulk", "Dragao", "Sombra",
        "Ghost", "Titan", "Blaze", "Storm", "Rex", "Alpha", "Omega", "Jaguar", "Pantera",
        "Trovao", "Mamba", "Lince", "Drako" };
    static final int[] SHIRTS = { 0xdc2626, 0x16a34a, 0xeab308, 0x9333ea, 0xea580c, 0x0891b2,
        0xdb2777, 0x64748b, 0x84cc16 };

    public Game(World w, Input in) { this.world = w; this.in = in; }

    float rr(float a, float b) { return a + rnd.nextFloat() * (b - a); }

    // ================================================================ partida

    public void startMatch() {
        ents.clear(); bots.clear(); loot.clear(); tracers.clear(); feed.clear();
        pl = new Entity();
        pl.isPlayer = true; pl.name = "Voce"; pl.shirt = 0x2563eb; pl.landed = false;
        ents.add(pl);
        for (int i = 0; i < NAMES.length; i++) {
            Bot b = new Bot();
            b.name = NAMES[i];
            b.shirt = SHIRTS[rnd.nextInt(SHIRTS.length)];
            b.active = false; b.landed = false;
            bots.add(b); ents.add(b);
        }
        float a = rnd.nextFloat() * 6.2832f;
        dirX = (float) Math.cos(a); dirZ = (float) Math.sin(a);
        float half = World.MR + 30f, off = rr(-45, 45);
        planeX = -dirX * half - dirZ * off;
        planeZ = -dirZ * half + dirX * off;
        planeDur = 2f * half / PLANE_SPD;
        planeT = 0;
        for (int i = 0; i < bots.size(); i++) bots.get(i).jumpAt = rr(planeDur * 0.12f, planeDur * 0.95f);
        pl.x = planeX; pl.z = planeZ; pl.y = PLANE_Y;
        pl.yaw = (float) Math.atan2(dirX, -dirZ);
        pl.pitch = -0.30f;
        spawnLoot();
        gasOn = false; gasShrink = false; gasX = 0; gasZ = 0; gasR = World.MR + 15f; gasT = 0; gasStage = 0;
        aim = false; time = 0; hurt = 0; near = null; rank = 0;
        in.clearPresses();
        phase = PLANE;
    }

    void spawnLoot() {
        int[] gw = { Wpn.DEAGLE, Wpn.DEAGLE, Wpn.M4A1, Wpn.M4A1, Wpn.M4A1, Wpn.MP40, Wpn.MP40, Wpn.MP40,
            Wpn.AK47, Wpn.AK47, Wpn.AK47, Wpn.DUAL, Wpn.DUAL, Wpn.DUAL, Wpn.AWP, Wpn.BARRETT };
        for (int i = 0; i < world.lootSpots.size(); i++) {
            float[] s = world.lootSpots.get(i);
            float r = rnd.nextFloat();
            if (r < 0.68f) loot.add(new Loot(Loot.GUN, gw[rnd.nextInt(gw.length)], s[0], s[1]));
            else if (r < 0.85f) loot.add(new Loot(Loot.MEDKIT, 0, s[0], s[1]));
            else loot.add(new Loot(Loot.VEST, 0, s[0], s[1]));
        }
    }

    public int countAlive() {
        int n = 0;
        for (int i = 0; i < ents.size(); i++) if (ents.get(i).alive) n++;
        return n;
    }

    // ================================================================ update

    public void update(float dt) {
        time += dt;
        if (phase == LOBBY) {
            lobbyT += dt;
            if (in.take(Input.B_START)) startMatch();
            updateCamera();
            return;
        }
        if (hurt > 0) hurt -= dt;
        if (hitMark > 0) hitMark -= dt;
        for (int i = feed.size() - 1; i >= 0; i--) {
            feed.get(i).t -= dt;
            if (feed.get(i).t <= 0) feed.remove(i);
        }
        for (int i = tracers.size() - 1; i >= 0; i--) {
            float[] t = tracers.get(i);
            t[6] -= dt;
            if (t[6] <= 0) tracers.remove(i);
        }

        planeT += dt;
        planeX += dirX * PLANE_SPD * dt;
        planeZ += dirZ * PLANE_SPD * dt;
        for (int i = 0; i < bots.size(); i++) {
            Bot b = bots.get(i);
            if (!b.active && b.alive && planeT >= b.jumpAt) jumpBot(b);
        }
        if (phase == PLANE) updatePlane(dt);
        else if (phase == FALL) updateFall(dt);
        else if (phase == PLAY) updatePlayer(dt);
        else if (phase == DEAD || phase == WIN) {
            if (in.take(Input.B_LOBBY)) { phase = LOBBY; updateCamera(); return; }
        }

        for (int i = 0; i < bots.size(); i++) botAI(bots.get(i), dt);
        if (phase != WIN) updateGas(dt);
        aliveCount = countAlive();
        if (phase == PLAY && pl.alive && aliveCount <= 1) { phase = WIN; rank = 1; }
        updateCamera();
    }

    void updatePlane(float dt) {
        pl.x = planeX; pl.z = planeZ; pl.y = PLANE_Y;
        float[] lk = in.takeLook();
        pl.yaw += lk[0] * 0.004f;
        pl.pitch -= lk[1] * 0.004f;
        if (in.take(Input.B_PLANEJUMP) || planeT >= planeDur - 1f) {
            phase = FALL;
            pl.landed = false; pl.chute = false; pl.vy = -30f; pl.onGround = false;
            pl.x = planeX; pl.z = planeZ; pl.y = PLANE_Y - 2f;
            in.clearPresses();
        }
    }

    void jumpBot(Bot b) {
        b.active = true; b.landed = false;
        b.x = planeX + rr(-3, 3); b.z = planeZ + rr(-3, 3); b.y = PLANE_Y - 2f;
        float ang = rr(0, 6.2832f), d = rr(10, 95);
        float px = b.x + (float) Math.cos(ang) * d, pz = b.z + (float) Math.sin(ang) * d;
        float r = (float) Math.sqrt(px * px + pz * pz);
        if (r > World.MR - 14) { px *= (World.MR - 14) / r; pz *= (World.MR - 14) / r; }
        b.tx = px; b.tz = pz;
        b.lx = b.x; b.lz = b.z;
    }

    void updateFall(float dt) {
        Entity p = pl;
        float[] lk = in.takeLook();
        p.yaw += lk[0] * 0.004f;
        p.pitch -= lk[1] * 0.004f;
        clampPitch(p);
        p.chute = p.y < 55f;
        p.vy = p.chute ? -7f : -30f;
        float mx = in.moveX, my = in.moveY;
        float len = (float) Math.sqrt(mx * mx + my * my);
        if (len > 1f) { mx /= len; my /= len; }
        float sy = (float) Math.sin(p.yaw), cyw = (float) Math.cos(p.yaw);
        float wx = sy * my + cyw * mx, wz = -cyw * my + sy * mx;
        float spd = p.chute ? 10f : 16f;
        p.x += wx * spd * dt; p.z += wz * spd * dt;
        clampMap(p);
        p.y += p.vy * dt;
        float g = world.groundAt(p.x, p.z, p.y);
        if (p.y <= g) {
            p.y = g; p.vy = 0; p.onGround = true; p.landed = true; p.chute = false;
            phase = PLAY;
            gasOn = true; gasT = 0;
        }
    }

    void clampPitch(Entity e) {
        if (e.pitch > 1.35f) e.pitch = 1.35f;
        if (e.pitch < -1.35f) e.pitch = -1.35f;
    }

    void clampMap(Entity e) {
        float r = (float) Math.sqrt(e.x * e.x + e.z * e.z);
        float lim = World.MR - 2f;
        if (r > lim) { e.x *= lim / r; e.z *= lim / r; }
    }

    // ---------------------------------------------------------------- jogador

    void updatePlayer(float dt) {
        Entity p = pl;
        if (!p.alive) return;
        updateWeapon(p, dt);
        Wpn w = p.gun();
        float sens = 0.0042f;
        if (aim) sens *= (w != null && w.sniper) ? 0.35f : 0.6f;
        float[] lk = in.takeLook();
        p.yaw += lk[0] * sens;
        p.pitch -= lk[1] * sens;
        clampPitch(p);

        if (in.take(Input.B_CROUCH)) p.crouch = !p.crouch;
        if (in.take(Input.B_AIM)) { if (w != null && !w.melee) aim = !aim; }
        for (int s = 0; s < 3; s++) {
            if (in.take(Input.B_S0 + s) && p.slot[s] >= 0 && p.cur != s) {
                p.cur = s; p.reloading = false;
                Wpn nw = p.gun();
                if (nw == null || nw.melee) aim = false;
            }
        }
        w = p.gun();
        if (in.take(Input.B_RELOAD)) startReload(p);
        if (in.take(Input.B_MEDKIT) && p.medkits > 0 && p.hp < 100f && p.healT <= 0) {
            p.medkits--; p.healT = 2f;
        }
        if (in.take(Input.B_JUMP) && p.onGround && !p.crouch) { p.vy = 7.2f; p.onGround = false; }

        float mx = in.moveX, my = in.moveY;
        float len = (float) Math.sqrt(mx * mx + my * my);
        if (len > 1f) { mx /= len; my /= len; }
        float spd = p.crouch ? 2.6f : (aim ? 3.4f : 5.8f);
        if (p.healT > 0) spd *= 0.5f;
        float sy = (float) Math.sin(p.yaw), cyw = (float) Math.cos(p.yaw);
        walk(p, sy * my + cyw * mx, -cyw * my + sy * mx, spd, dt);
        physics(p, dt);

        // loot proximo
        near = null;
        float bd = 2.6f * 2.6f;
        for (int i = 0; i < loot.size(); i++) {
            Loot l = loot.get(i);
            float dx = l.x - p.x, dz = l.z - p.z, d2 = dx * dx + dz * dz;
            if (d2 < bd && Math.abs(l.y - p.y) < 2.5f) { bd = d2; near = l; }
        }
        if (in.take(Input.B_PICKUP) && near != null) { pickup(p, near); near = null; }

        updateCamera();
        if (in.fire) playerFire();
    }

    void walk(Entity e, float wx, float wz, float spd, float dt) {
        float ox = e.x, oz = e.z;
        e.x += wx * spd * dt;
        e.z += wz * spd * dt;
        world.resolve(e, 0.4f);
        clampMap(e);
        float mv = (float) Math.sqrt((e.x - ox) * (e.x - ox) + (e.z - oz) * (e.z - oz)) / Math.max(dt, 0.0001f);
        e.speed = mv;
        if (mv > 0.3f) e.walk += mv * dt * 2.2f;
    }

    void physics(Entity e, float dt) {
        if (!e.onGround) e.vy -= 22f * dt; else e.vy = 0;
        e.y += e.vy * dt;
        float g = world.groundAt(e.x, e.z, e.y);
        if (e.y <= g && e.vy <= 0) { e.y = g; e.vy = 0; e.onGround = true; }
        else e.onGround = false;
    }

    void updateWeapon(Entity e, float dt) {
        if (e.fireCd > 0) e.fireCd -= dt;
        if (e.hitFlash > 0) e.hitFlash -= dt;
        if (e.reloading) {
            e.reloadT -= dt;
            if (e.reloadT <= 0) {
                e.reloading = false;
                Wpn w = e.gun();
                if (w != null && !w.melee) e.ammo[e.cur] = w.mag;
            }
        }
        if (e.healT > 0) {
            e.healT -= dt;
            if (e.healT <= 0) e.hp = Math.min(100f, e.hp + 60f);
        }
    }

    void startReload(Entity e) {
        Wpn w = e.gun();
        if (w == null || w.melee || e.reloading || e.ammo[e.cur] >= w.mag) return;
        e.reloading = true;
        e.reloadT = w.reloadMs / 1000f;
    }

    void pickup(Entity e, Loot l) {
        if (l.type == Loot.GUN) {
            int gi = l.gun;
            for (int s = 0; s < 2; s++) {
                if (e.slot[s] == gi) { e.ammo[s] = Wpn.ALL[gi].mag; loot.remove(l); return; }
            }
            int s;
            if (e.slot[0] < 0) s = 0;
            else if (e.slot[1] < 0) s = 1;
            else s = (e.cur == 1) ? 1 : 0;
            if (e.slot[s] >= 0) {
                Loot d = new Loot(Loot.GUN, e.slot[s], e.x + 0.8f, e.z + 0.8f);
                d.y = e.y;
                loot.add(d);
            }
            e.slot[s] = gi;
            e.ammo[s] = Wpn.ALL[gi].mag;
            e.cur = s;
            e.reloading = false;
        } else if (l.type == Loot.MEDKIT) {
            if (e.medkits >= 4) return;
            e.medkits++;
        } else {
            e.armor = 100f;
        }
        loot.remove(l);
    }

    // ----------------------------------------------------------------- tiros

    void playerFire() {
        Entity p = pl;
        Wpn w = p.gun();
        if (w == null || p.fireCd > 0 || p.reloading || p.healT > 0) return;
        if (w.melee) {
            p.fireCd = w.rateMs / 1000f;
            meleeHit(p, w, 1f);
            return;
        }
        if (p.ammo[p.cur] <= 0) { startReload(p); return; }
        p.ammo[p.cur]--;
        p.fireCd = w.rateMs / 1000f;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float fx = (float) Math.sin(p.yaw) * cp, fy = sp, fz = -(float) Math.cos(p.yaw) * cp;
        float ex = p.x, ey = p.eye(), ez = p.z;
        // ponto mirado pela camera
        float t = pickDist(p, cx, cy, cz, fx, fy, fz, 150f);
        float px = cx + fx * t, py = cy + fy * t, pz = cz + fz * t;
        float dx = px - ex, dy = py - ey, dz = pz - ez;
        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dl < 0.8f || dx * fx + dy * fy + dz * fz < 0.3f) { dx = fx; dy = fy; dz = fz; dl = 1f; }
        dx /= dl; dy /= dl; dz /= dl;
        float spread = aim ? 0.003f : 0.011f;
        if (p.speed > 1f) spread += 0.012f;
        dx += (rnd.nextFloat() - 0.5f) * spread * 2;
        dy += (rnd.nextFloat() - 0.5f) * spread * 2;
        dz += (rnd.nextFloat() - 0.5f) * spread * 2;
        shoot(p, ex, ey, ez, dx, dy, dz, w, 1f);
        p.pitch += 0.004f + (w.sniper ? 0.03f : 0f);
    }

    float pickDist(Entity self, float ox, float oy, float oz, float dx, float dy, float dz, float maxT) {
        float best = world.raycast(ox, oy, oz, dx, dy, dz, maxT);
        for (int i = 0; i < ents.size(); i++) {
            Entity t = ents.get(i);
            if (t == self || !t.alive || !t.active) continue;
            float hy = t.y + t.height();
            float th = raySphere(ox, oy, oz, dx, dy, dz, t.x, hy - 0.15f, t.z, 0.22f);
            if (th >= 0 && th < best) best = th;
            float tb = rayCyl(ox, oy, oz, dx, dy, dz, t.x, t.z, 0.42f, t.y, hy - 0.3f);
            if (tb >= 0 && tb < best) best = tb;
        }
        return best;
    }

    void meleeHit(Entity e, Wpn w, float mul) {
        float fx = (float) Math.sin(e.yaw), fz = -(float) Math.cos(e.yaw);
        for (int i = 0; i < ents.size(); i++) {
            Entity t = ents.get(i);
            if (t == e || !t.alive || !t.active) continue;
            float dx = t.x - e.x, dz = t.z - e.z;
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d > 2.6f || Math.abs(t.y - e.y) > 1.5f) continue;
            if (d > 0.3f && (dx * fx + dz * fz) / d < 0.35f) continue;
            float dmg = w.dmgMin + rnd.nextFloat() * (w.dmgMax - w.dmgMin);
            damage(t, e, dmg * mul, false, w);
            return;
        }
    }

    void shoot(Entity e, float ox, float oy, float oz, float dx, float dy, float dz, Wpn w, float mul) {
        float maxT = w.sniper ? 200f : 130f;
        float best = world.raycast(ox, oy, oz, dx, dy, dz, maxT);
        Entity hit = null;
        boolean head = false;
        for (int i = 0; i < ents.size(); i++) {
            Entity t = ents.get(i);
            if (t == e || !t.alive || !t.active) continue;
            float ddx = t.x - ox, ddz = t.z - oz;
            if (ddx * ddx + ddz * ddz > maxT * maxT) continue;
            float hy = t.y + t.height();
            float th = raySphere(ox, oy, oz, dx, dy, dz, t.x, hy - 0.15f, t.z, 0.22f);
            if (th >= 0 && th < best) { best = th; hit = t; head = true; }
            float tb = rayCyl(ox, oy, oz, dx, dy, dz, t.x, t.z, 0.42f, t.y, hy - 0.3f);
            if (tb >= 0 && tb < best) { best = tb; hit = t; head = false; }
        }
        float mx = ox + dx * 0.9f, my = oy - 0.25f + dy * 0.9f, mz = oz + dz * 0.9f;
        tracers.add(new float[] { mx, my, mz, ox + dx * best, oy + dy * best, oz + dz * best, 0.07f });
        if (hit != null) {
            float dmg = head ? w.head * mul : (w.dmgMin + rnd.nextFloat() * (w.dmgMax - w.dmgMin)) * mul;
            damage(hit, e, dmg, head, w);
        }
    }

    void damage(Entity t, Entity src, float dmg, boolean head, Wpn w) {
        if (!t.alive) return;
        if (!head && t.armor > 0) {
            float ab = Math.min(t.armor, dmg * 0.4f);
            t.armor -= ab;
            dmg -= ab;
        }
        t.hp -= dmg;
        t.hitFlash = 0.25f;
        if (t == pl) hurt = 0.6f;
        if (src == pl) { hitMark = 0.2f; hitHead = head; }
        if (t instanceof Bot && src != null) {
            Bot b = (Bot) t;
            b.alertT = 4f;
            if (b.target == null && src.alive) { b.target = src; b.reactT = 0.3f; }
        }
        if (t.hp <= 0) kill(t, src, w == null ? "Zona" : w.name);
    }

    void kill(Entity t, Entity src, String how) {
        t.alive = false;
        t.hp = 0;
        if (src != null && src != t) src.kills++;
        Feed f = new Feed();
        f.s = (src == null ? "Zona" : src.name) + " eliminou " + t.name + " (" + how + ")";
        feed.add(f);
        if (feed.size() > 5) feed.remove(0);
        for (int s = 0; s < 2; s++) {
            if (t.slot[s] >= 0) {
                Loot d = new Loot(Loot.GUN, t.slot[s], t.x + (s == 0 ? 0.7f : -0.7f), t.z);
                d.y = t.y;
                loot.add(d);
            }
        }
        if (t.medkits > 0) { Loot d = new Loot(Loot.MEDKIT, 0, t.x, t.z + 0.8f); d.y = t.y; loot.add(d); }
        if (t == pl) {
            aim = false;
            in.fire = false;
            rank = countAlive() + 1;
            phase = DEAD;
        }
    }

    static float raySphere(float ox, float oy, float oz, float dx, float dy, float dz,
                           float cx, float cy, float cz, float r) {
        float ex = ox - cx, ey = oy - cy, ez = oz - cz;
        float b = ex * dx + ey * dy + ez * dz;
        float c = ex * ex + ey * ey + ez * ez - r * r;
        float disc = b * b - c;
        if (disc < 0) return -1f;
        float sq = (float) Math.sqrt(disc);
        float t = -b - sq;
        if (t < 0) t = -b + sq;
        return t < 0 ? -1f : t;
    }

    static float rayCyl(float ox, float oy, float oz, float dx, float dy, float dz,
                        float cx, float cz, float r, float y0, float y1) {
        float a = dx * dx + dz * dz;
        if (a < 1e-8f) return -1f;
        float ex = ox - cx, ez = oz - cz;
        float b = 2 * (ex * dx + ez * dz);
        float c = ex * ex + ez * ez - r * r;
        float disc = b * b - 4 * a * c;
        if (disc < 0) return -1f;
        float sq = (float) Math.sqrt(disc);
        float t = (-b - sq) / (2 * a);
        if (t < 0) { t = (-b + sq) / (2 * a); if (t < 0) return -1f; }
        float y = oy + dy * t;
        if (y < y0 || y > y1) return -1f;
        return t;
    }

    // ------------------------------------------------------------------- gas

    void updateGas(float dt) {
        if (!gasOn) return;
        gasT += dt;
        int st = Math.min(gasStage, GF.length - 1);
        if (!gasShrink) {
            if (gasT >= GWAIT[st] && gasStage < GF.length) {
                gasShrink = true; gasT = 0;
                gFX = gasX; gFZ = gasZ; gFR = gasR;
                gTR = (st >= GF.length - 1) ? 2f : Math.max(8f, gFR * GF[st]);
                float maxOff = Math.max(0f, (gFR - gTR) * 0.8f);
                float a = rnd.nextFloat() * 6.2832f, d = rnd.nextFloat() * maxOff;
                gTX = gFX + (float) Math.cos(a) * d;
                gTZ = gFZ + (float) Math.sin(a) * d;
            }
        } else {
            float f = Math.min(1f, gasT / GSHR[st]);
            gasR = gFR + (gTR - gFR) * f;
            gasX = gFX + (gTX - gFX) * f;
            gasZ = gFZ + (gTZ - gFZ) * f;
            if (f >= 1f) {
                gasShrink = false; gasT = 0;
                if (gasStage < GF.length - 1) gasStage++;
                else gasStage = GF.length - 1;
            }
        }
        float dps = GDMG[Math.min(gasStage, GDMG.length - 1)];
        for (int i = 0; i < ents.size(); i++) {
            Entity e = ents.get(i);
            if (!e.alive || !e.active || !e.landed) continue;
            float dx = e.x - gasX, dz = e.z - gasZ;
            if (dx * dx + dz * dz > gasR * gasR) {
                e.hp -= dps * dt;
                if (e == pl) hurt = Math.max(hurt, 0.15f);
                if (e.hp <= 0) kill(e, null, "Zona");
            }
        }
    }

    public boolean playerOutside() {
        if (!gasOn || pl == null) return false;
        float dx = pl.x - gasX, dz = pl.z - gasZ;
        return dx * dx + dz * dz > gasR * gasR;
    }

    public String gasText() {
        if (!gasOn) return "Zona ativa ao pousar";
        if (gasShrink) return "ZONA FECHANDO";
        int st = Math.min(gasStage, GWAIT.length - 1);
        int left = (int) Math.max(0, GWAIT[st] - gasT);
        return "ZONA FECHA EM " + (left / 60) + ":" + (left % 60 < 10 ? "0" : "") + (left % 60);
    }

    // ------------------------------------------------------------------- bots

    float angDiff(float a, float b) {
        float d = b - a;
        while (d > Math.PI) d -= 6.2832f;
        while (d < -Math.PI) d += 6.2832f;
        return d;
    }

    void botAI(Bot b, float dt) {
        if (!b.alive || !b.active) return;
        if (!b.landed) {
            float dx = b.tx - b.x, dz = b.tz - b.z;
            float dl = (float) Math.sqrt(dx * dx + dz * dz);
            b.chute = b.y < 55f;
            float sp = b.chute ? 9f : 16f;
            if (dl > 2f) { b.x += dx / dl * sp * dt; b.z += dz / dl * sp * dt; b.yaw = (float) Math.atan2(dx, -dz); }
            b.vy = b.chute ? -7f : -30f;
            b.y += b.vy * dt;
            float g = world.groundAt(b.x, b.z, b.y);
            if (b.y <= g) { b.y = g; b.vy = 0; b.landed = true; b.onGround = true; b.chute = false; newWaypoint(b); }
            return;
        }
        updateWeapon(b, dt);
        b.reactT -= dt; b.strafeT -= dt; b.thinkT -= dt; b.alertT -= dt; b.wayT -= dt;

        b.stuckT += dt;
        if (b.stuckT > 1.3f) {
            float mv = (float) Math.sqrt((b.x - b.lx) * (b.x - b.lx) + (b.z - b.lz) * (b.z - b.lz));
            b.lx = b.x; b.lz = b.z; b.stuckT = 0;
            if (mv < 0.6f && b.healT <= 0) {
                newWaypoint(b);
                if (b.onGround) { b.vy = 7f; b.onGround = false; }
            }
        }
        if (b.thinkT <= 0) { b.thinkT = rr(0.2f, 0.4f); scan(b); }

        boolean hasGun = b.slot[0] >= 0 || b.slot[1] >= 0;
        if (hasGun && (b.gun() == null || b.gun().melee)) b.cur = b.slot[0] >= 0 ? 0 : 1;
        Wpn w = b.gun();
        Entity t = b.target;
        if (t != null && (!t.alive || !t.active || !t.landed)) { t = null; b.target = null; }

        float wx = 0, wz = 0, spd = 4.8f;
        boolean outGas = gasOn && ((b.x - gasX) * (b.x - gasX) + (b.z - gasZ) * (b.z - gasZ) > (gasR - 7f) * (gasR - 7f));
        float faceYaw = b.yaw;
        boolean facing = false;

        if (b.hp < 45f && b.medkits > 0 && t == null && b.healT <= 0) { b.medkits--; b.healT = 2f; }

        if (b.healT > 0) {
            spd = 0;
        } else if (outGas && (t == null || !hasGun)) {
            b.tx = gasX; b.tz = gasZ;
            float dx = b.tx - b.x, dz = b.tz - b.z, dl = (float) Math.sqrt(dx * dx + dz * dz) + 0.01f;
            wx = dx / dl; wz = dz / dl; spd = 6.2f;
            faceYaw = (float) Math.atan2(dx, -dz);
            facing = true;
        } else if (t != null && hasGun && w != null && !w.melee) {
            float dx = t.x - b.x, dz = t.z - b.z;
            float dist = (float) Math.sqrt(dx * dx + dz * dz) + 0.01f;
            float want = (float) Math.atan2(dx, -dz);
            b.yaw += angDiff(b.yaw, want) * Math.min(1f, 6f * dt);
            b.pitch = (float) Math.atan2((t.y + 1.2f) - b.eye(), dist);
            if (b.strafeT <= 0) { b.strafeT = rr(0.8f, 2.0f); b.strafeDir = rnd.nextBoolean() ? 1f : -1f; }
            float pref = w.sniper ? 45f : (w.rateMs < 130 ? 16f : 24f);
            float fw = dist > pref + 6f ? 1f : (dist < pref - 8f ? -1f : 0f);
            float fx = dx / dist, fz = dz / dist;
            wx = fx * fw - fz * b.strafeDir * 0.8f;
            wz = fz * fw + fx * b.strafeDir * 0.8f;
            spd = 4.2f;
            if (b.ammo[b.cur] <= 0) startReload(b);
            else if (b.reactT <= 0 && !b.reloading && Math.abs(angDiff(b.yaw, want)) < 0.22f) {
                if (b.pauseT > 0) b.pauseT -= dt;
                else {
                    b.burstT -= dt;
                    if (b.burstT <= 0) { b.pauseT = rr(0.5f, 1.3f); b.burstT = rr(0.5f, 1.3f); }
                    else if (b.fireCd <= 0) botFire(b, t, w, dist);
                }
            }
            facing = true;
            faceYaw = b.yaw;
        } else if (!hasGun) {
            if (b.lootT != null && !loot.contains(b.lootT)) b.lootT = null;
            if (b.lootT != null) {
                float dx = b.lootT.x - b.x, dz = b.lootT.z - b.z;
                float dl = (float) Math.sqrt(dx * dx + dz * dz) + 0.01f;
                if (dl < 1.4f) pickup(b, b.lootT);
                else { wx = dx / dl; wz = dz / dl; spd = 5.4f; faceYaw = (float) Math.atan2(dx, -dz); facing = true; }
            } else roam(b);
        } else {
            if (b.lootT != null && !loot.contains(b.lootT)) b.lootT = null;
            if (b.lootT != null) {
                float dx = b.lootT.x - b.x, dz = b.lootT.z - b.z;
                float dl = (float) Math.sqrt(dx * dx + dz * dz) + 0.01f;
                if (dl < 1.4f) pickup(b, b.lootT);
                else { wx = dx / dl; wz = dz / dl; faceYaw = (float) Math.atan2(dx, -dz); facing = true; }
            } else {
                float dx = b.tx - b.x, dz = b.tz - b.z;
                float dl = (float) Math.sqrt(dx * dx + dz * dz) + 0.01f;
                if (dl < 3f || b.wayT <= 0) newWaypoint(b);
                else { wx = dx / dl; wz = dz / dl; faceYaw = (float) Math.atan2(dx, -dz); facing = true; }
            }
        }
        if (facing && !(t != null && hasGun)) b.yaw += angDiff(b.yaw, faceYaw) * Math.min(1f, 8f * dt);
        if (b.healT > 0) { wx = 0; wz = 0; }
        walk(b, wx, wz, spd, dt);
        physics(b, dt);
    }

    void roam(Bot b) {
        float dx = b.tx - b.x, dz = b.tz - b.z;
        if (dx * dx + dz * dz < 9f || b.wayT <= 0) newWaypoint(b);
    }

    void newWaypoint(Bot b) {
        float ang = rnd.nextFloat() * 6.2832f, d = rr(15, 60);
        float px = b.x + (float) Math.cos(ang) * d, pz = b.z + (float) Math.sin(ang) * d;
        float cxx = gasOn ? gasX : 0f, czz = gasOn ? gasZ : 0f, lim = gasOn ? gasR * 0.8f : World.MR - 10f;
        float dx = px - cxx, dz = pz - czz, r = (float) Math.sqrt(dx * dx + dz * dz);
        if (r > lim) { px = cxx + dx / r * lim; pz = czz + dz / r * lim; }
        b.tx = px; b.tz = pz;
        b.wayT = rr(6f, 14f);
    }

    void scan(Bot b) {
        boolean hasGun = b.slot[0] >= 0 || b.slot[1] >= 0;
        Wpn w = b.gun();
        float range = (w != null && w.sniper) ? 100f : 60f;
        float fx = (float) Math.sin(b.yaw), fz = -(float) Math.cos(b.yaw);
        Entity best = null;
        float bd = range * range;
        for (int i = 0; i < ents.size(); i++) {
            Entity t = ents.get(i);
            if (t == b || !t.alive || !t.active || !t.landed) continue;
            float dx = t.x - b.x, dz = t.z - b.z, d2 = dx * dx + dz * dz;
            if (d2 > bd) continue;
            float d = (float) Math.sqrt(d2) + 0.01f;
            boolean sees = b.target == t || b.alertT > 0 || d < 14f || (dx * fx + dz * fz) / d > 0.15f;
            if (!sees) continue;
            float oy = b.eye(), ty = t.y + 1.2f;
            float dy = ty - oy, dl = (float) Math.sqrt(d2 + dy * dy);
            float hit = world.raycast(b.x, oy, b.z, dx / dl, dy / dl, dz / dl, dl);
            if (hit < dl - 0.8f) continue;
            best = t; bd = d2;
        }
        if (best != null && b.target == null) b.reactT = rr(0.35f, 0.8f);
        b.target = best;

        if (b.lootT == null || !loot.contains(b.lootT)) {
            b.lootT = null;
            float ld = hasGun ? 25f * 25f : 90f * 90f;
            for (int i = 0; i < loot.size(); i++) {
                Loot l = loot.get(i);
                if (!hasGun && l.type != Loot.GUN) continue;
                if (hasGun && l.type == Loot.GUN) continue;
                if (hasGun && l.type == Loot.MEDKIT && b.medkits >= 2) continue;
                float dx = l.x - b.x, dz = l.z - b.z, d2 = dx * dx + dz * dz;
                if (d2 < ld) { ld = d2; b.lootT = l; }
            }
        }
    }

    void botFire(Bot b, Entity t, Wpn w, float dist) {
        b.ammo[b.cur]--;
        b.fireCd = (w.rateMs / 1000f) * (w.sniper ? 1.3f : 1.7f);
        float ex = b.x, ey = b.eye(), ez = b.z;
        float tx2 = t.x, ty2 = t.y + 1.15f, tz2 = t.z;
        float dx = tx2 - ex, dy = ty2 - ey, dz = tz2 - ez;
        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.01f;
        dx /= dl; dy /= dl; dz /= dl;
        float spread = (w.sniper ? 0.01f : 0.022f) + dist * 0.0009f;
        dx += (rnd.nextFloat() - 0.5f) * spread * 2;
        dy += (rnd.nextFloat() - 0.5f) * spread * 2;
        dz += (rnd.nextFloat() - 0.5f) * spread * 2;
        shoot(b, ex, ey, ez, dx, dy, dz, w, t == pl ? 0.7f : 0.8f);
    }

    // ----------------------------------------------------------------- camera

    public void updateCamera() {
        if (phase == LOBBY) {
            cx = 0; cy = 1.25f; cz = 3.6f; tx = 0; ty = 1.0f; tz = 0; fov = 45f;
            thirdPerson = true;
            return;
        }
        if (phase == PLANE) {
            cx = planeX - dirX * 24f; cz = planeZ - dirZ * 24f; cy = PLANE_Y + 9f;
            tx = planeX; ty = PLANE_Y; tz = planeZ; fov = 65f; thirdPerson = true;
            return;
        }
        Entity p = pl;
        float cp = (float) Math.cos(p.pitch), sp = (float) Math.sin(p.pitch);
        float fx = (float) Math.sin(p.yaw) * cp, fy = sp, fz = -(float) Math.cos(p.yaw) * cp;
        float rx = (float) Math.cos(p.yaw), rz = (float) Math.sin(p.yaw);
        float ex = p.x, ey = p.eye(), ez = p.z;
        Wpn w = p.gun();
        boolean scope = aim && w != null && !w.melee && p.alive && phase == PLAY;
        if (scope) {
            cx = ex + fx * 0.15f; cy = ey + fy * 0.15f; cz = ez + fz * 0.15f;
            fov = w.sniper ? 60f / (float) Math.sqrt(w.zoom) : 48f;
            thirdPerson = false;
        } else {
            float dist = phase == FALL ? 7f : 3.1f;
            float dx = -fx * dist + rx * 0.55f, dy = -fy * dist + 0.3f, dz = -fz * dist + rz * 0.55f;
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float t = world.raycast(ex, ey, ez, dx / len, dy / len, dz / len, len);
            float use = Math.max(0.35f, Math.min(len, t - 0.25f));
            cx = ex + dx / len * use; cy = ey + dy / len * use; cz = ez + dz / len * use;
            if (cy < 0.35f) cy = 0.35f;
            fov = 65f;
            thirdPerson = true;
        }
        tx = cx + fx * 10f; ty = cy + fy * 10f; tz = cz + fz * 10f;
    }
}
