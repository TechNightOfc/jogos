package com.freefire3d;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Arrays;

/** Conjunto de caixas coloridas (voxel) enviado para a GPU de uma vez. */
public class Batch {
    static final ArrayList<Batch> ALL = new ArrayList<Batch>();

    float[] d = new float[9 * 600];
    int n = 0;
    int vbo = 0;
    int verts = 0;

    public Batch() { ALL.add(this); }

    private void ensure(int add) {
        if (n + add > d.length) d = Arrays.copyOf(d, Math.max(d.length * 2, n + add));
    }

    private void v(float x, float y, float z, float nx, float ny, float nz,
                   float r, float g, float b) {
        ensure(9);
        d[n++] = x; d[n++] = y; d[n++] = z;
        d[n++] = nx; d[n++] = ny; d[n++] = nz;
        d[n++] = r; d[n++] = g; d[n++] = b;
    }

    private void face(float nx, float ny, float nz,
                      float ax, float ay, float az, float bx, float by, float bz,
                      float cx, float cy, float cz, float dx, float dy, float dz,
                      float r, float g, float b) {
        v(ax, ay, az, nx, ny, nz, r, g, b);
        v(bx, by, bz, nx, ny, nz, r, g, b);
        v(cx, cy, cz, nx, ny, nz, r, g, b);
        v(ax, ay, az, nx, ny, nz, r, g, b);
        v(cx, cy, cz, nx, ny, nz, r, g, b);
        v(dx, dy, dz, nx, ny, nz, r, g, b);
    }

    public void box(float cx, float cy, float cz, float sx, float sy, float sz, int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float x0 = cx - sx / 2, x1 = cx + sx / 2;
        float y0 = cy - sy / 2, y1 = cy + sy / 2;
        float z0 = cz - sz / 2, z1 = cz + sz / 2;
        face(1, 0, 0, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, b);
        face(-1, 0, 0, x0, y0, z1, x0, y1, z1, x0, y1, z0, x0, y0, z0, r, g, b);
        face(0, 1, 0, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, b);
        face(0, -1, 0, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1, r, g, b);
        face(0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b);
        face(0, 0, -1, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, b);
    }

    /** Quadrado plano virado para cima (chao). */
    public void quadTop(float cx, float y, float cz, float size, int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float h = size / 2;
        face(0, 1, 0, cx - h, y, cz - h, cx - h, y, cz + h, cx + h, y, cz + h, cx + h, y, cz - h, r, g, b);
    }

    public void upload() {
        if (n == 0) return;
        FloatBuffer fb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(d, 0, n);
        fb.position(0);
        int[] id = new int[1];
        GLES20.glGenBuffers(1, id, 0);
        vbo = id[0];
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 4, fb, GLES20.GL_STATIC_DRAW);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        verts = n / 9;
    }

    public static void reuploadAll() {
        for (int i = 0; i < ALL.size(); i++) {
            Batch b = ALL.get(i);
            b.vbo = 0;
            b.upload();
        }
    }

    public void draw(int aPos, int aNor, int aCol) {
        if (vbo == 0) upload();
        if (vbo == 0) return;
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 36, 0);
        GLES20.glEnableVertexAttribArray(aNor);
        GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 36, 12);
        GLES20.glEnableVertexAttribArray(aCol);
        GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 36, 24);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, verts);
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aNor);
        GLES20.glDisableVertexAttribArray(aCol);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }
}
