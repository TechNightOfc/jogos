package com.freefire3d;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

/** Superficie OpenGL + tratamento de multitoque. */
public class GameView extends GLSurfaceView {
    static final int NONE = 0, STICK = 1, LOOK = 2, BTN = 3, FIRE = 4;
    final Game game;
    final Hud hud;
    final Input in;
    final GameRenderer renderer;
    final int[] role = new int[32];
    final float[] lx = new float[32], ly = new float[32];

    public GameView(Context ctx, Game game, Hud hud, Input in) {
        super(ctx);
        this.game = game; this.hud = hud; this.in = in;
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        renderer = new GameRenderer(game, hud, in);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (act) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) move(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < role.length; i++) up(i);
                break;
        }
        return true;
    }

    void down(int id, float x, float y) {
        if (id < 0 || id >= role.length) return;
        lx[id] = x; ly[id] = y;
        int b = hud.hit(x, y, game);
        if (b >= 0) {
            if (b == Input.B_FIRE) { in.fire = true; role[id] = FIRE; }
            else { in.press(b); role[id] = BTN; }
            return;
        }
        int ph = game.phase;
        if (ph == Game.PLAY || ph == Game.FALL) {
            if (x < hud.W * 0.4f && y > hud.H * 0.3f) {
                role[id] = STICK;
                hud.stickOn = true;
                hud.stickOX = x; hud.stickOY = y; hud.stickKX = x; hud.stickKY = y;
                in.moveX = 0; in.moveY = 0;
                return;
            }
            role[id] = LOOK;
        } else if (ph == Game.PLANE) {
            role[id] = LOOK;
        } else {
            role[id] = NONE;
        }
    }

    void move(int id, float x, float y) {
        if (id < 0 || id >= role.length) return;
        int r = role[id];
        if (r == STICK) {
            float R = 9 * hud.u;
            float dx = x - hud.stickOX, dy = y - hud.stickOY;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > R) { dx = dx / len * R; dy = dy / len * R; }
            hud.stickKX = hud.stickOX + dx;
            hud.stickKY = hud.stickOY + dy;
            float nx = dx / R, ny = -dy / R;
            if (Math.abs(nx) < 0.08f) nx = 0;
            if (Math.abs(ny) < 0.08f) ny = 0;
            in.moveX = nx; in.moveY = ny;
        } else if (r == LOOK || r == FIRE) {
            in.addLook(x - lx[id], y - ly[id]);
        }
        lx[id] = x; ly[id] = y;
    }

    void up(int id) {
        if (id < 0 || id >= role.length) return;
        int r = role[id];
        if (r == STICK) { hud.stickOn = false; in.moveX = 0; in.moveY = 0; }
        else if (r == FIRE) in.fire = false;
        role[id] = NONE;
    }
}
