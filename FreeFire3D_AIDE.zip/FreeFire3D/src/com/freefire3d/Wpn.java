package com.freefire3d;

/** Tabela de armas (valores copiados do jogo em HTML v36). */
public class Wpn {
    public final String name;
    public final int dmgMin, dmgMax, head, rateMs, mag, color, reloadMs;
    public final float len, zoom;
    public final boolean sniper, melee;

    Wpn(String name, int dmgMin, int dmgMax, int head, int rateMs, int mag,
        int color, float len, boolean sniper, float zoom, int reloadMs, boolean melee) {
        this.name = name; this.dmgMin = dmgMin; this.dmgMax = dmgMax; this.head = head;
        this.rateMs = rateMs; this.mag = mag; this.color = color; this.len = len;
        this.sniper = sniper; this.zoom = zoom; this.reloadMs = reloadMs; this.melee = melee;
    }

    public static final int DEAGLE = 0, M4A1 = 1, MP40 = 2, AK47 = 3, AWP = 4,
            BARRETT = 5, DUAL = 6, KATANA = 7;

    public static final Wpn[] ALL = {
        new Wpn("Desert Eagle", 38, 48, 290, 350, 16, 0xd1d5db, 1.0f, false, 0, 1300, false),
        new Wpn("M4A1",         22, 28,  85, 100, 30, 0x3b82f6, 1.5f, false, 0, 1500, false),
        new Wpn("MP40",         16, 21,  60,  70, 32, 0xeab308, 1.3f, false, 0, 1500, false),
        new Wpn("AK-47",        27, 35, 110, 125, 30, 0xb45309, 1.6f, false, 0, 1500, false),
        new Wpn("AWP",         110, 125, 330, 1200, 5, 0x3f5d2a, 2.0f, true, 16, 1600, false),
        new Wpn("Barrett",      95, 110, 260, 600,  7, 0x111827, 2.2f, true, 11, 2000, false),
        new Wpn("Pistola Dupla",14, 18,  68,  88, 36, 0x94a3b8, 1.2f, false, 0, 1300, false),
        new Wpn("Katana",       40, 50,  90, 450,  0, 0xe5e7eb, 1.0f, false, 0, 0, true)
    };
}
