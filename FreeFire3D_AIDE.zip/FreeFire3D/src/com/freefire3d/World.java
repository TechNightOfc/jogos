package com.freefire3d;

import java.util.ArrayList;
import java.util.Random;

/** Mapa (ilha Bermudas simplificada): casas, arvores, pedras, containers e colisao. */
public class World {
    public static final float MR = 190f;
    static final int GN = 26;
    static final float GC = 16f, GO = 208f;

    public static class Box {
        public float x0, y0, z0, x1, y1, z1;
        int stamp;
    }

    public final ArrayList<Box> boxes = new ArrayList<Box>();
    @SuppressWarnings("unchecked")
    final ArrayList<Box>[] grid = new ArrayList[GN * GN];
    public final Batch batch = new Batch();
    public final ArrayList<float[]> lootSpots = new ArrayList<float[]>();
    final ArrayList<float[]> rects = new ArrayList<float[]>();
    final Random rnd = new Random(36);
    int stampN = 0;

    static final int[] WALLS = { 0xf5e6c8, 0xdbeafe, 0xfde2e4, 0xfef3c7, 0xd9f99d, 0xe2e8f0 };
    static final int[] ROOFS = { 0xb91c1c, 0x7c2d12, 0x1e3a8a, 0x44403c, 0x166534 };
    static final int[] GREENS = { 0x2e7d32, 0x388e3c, 0x1b5e20, 0x43a047 };

    public World() {
        for (int i = 0; i < grid.length; i++) grid[i] = new ArrayList<Box>();
        build();
    }

    float rr(float a, float b) { return a + rnd.nextFloat() * (b - a); }

    static int cell(float v) {
        int c = (int) Math.floor((v + GO) / GC);
        return c < 0 ? 0 : (c >= GN ? GN - 1 : c);
    }

    void addCollider(float x0, float y0, float z0, float x1, float y1, float z1) {
        Box b = new Box();
        b.x0 = x0; b.y0 = y0; b.z0 = z0; b.x1 = x1; b.y1 = y1; b.z1 = z1;
        boxes.add(b);
        int i0 = cell(x0), i1 = cell(x1), j0 = cell(z0), j1 = cell(z1);
        for (int i = i0; i <= i1; i++)
            for (int j = j0; j <= j1; j++) grid[i * GN + j].add(b);
    }

    void solid(float cx, float y0, float cz, float sx, float sy, float sz, int color) {
        batch.box(cx, y0 + sy / 2, cz, sx, sy, sz, color);
        addCollider(cx - sx / 2, y0, cz - sz / 2, cx + sx / 2, y0 + sy, cz + sz / 2);
    }

    void deco(float cx, float y0, float cz, float sx, float sy, float sz, int color) {
        batch.box(cx, y0 + sy / 2, cz, sx, sy, sz, color);
    }

    boolean free(float x, float z, float margin) {
        for (int i = 0; i < rects.size(); i++) {
            float[] r = rects.get(i);
            if (x > r[0] - margin && x < r[2] + margin && z > r[1] - margin && z < r[3] + margin) return false;
        }
        return true;
    }

    void build() {
        // chao: grama / areia
        for (float x = -200; x < 200; x += 10) {
            for (float z = -200; z < 200; z += 10) {
                float cx = x + 5, cz = z + 5;
                float d = (float) Math.sqrt(cx * cx + cz * cz);
                if (d > MR + 7) continue;
                int c;
                if (d > MR - 10) c = rnd.nextBoolean() ? 0xe8d6a4 : 0xdcc994;
                else {
                    int k = rnd.nextInt(3);
                    c = k == 0 ? 0x62a944 : (k == 1 ? 0x58a03c : 0x6bb04b);
                }
                batch.quadTop(cx, 0f, cz, 10.05f, c);
            }
        }
        // agua
        batch.quadTop(0, -0.45f, 0, 1400f, 0x2f7fc1);

        // vilas e casas
        float[][] towns = { {0, 0}, {70, 40}, {-80, 50}, {50, -90}, {-60, -80}, {120, -20},
                {-130, -30}, {10, 130}, {-20, -140} };
        for (int t = 0; t < towns.length; t++) {
            int want = t == 0 ? 7 : 5;
            int tries = 0, made = 0;
            while (made < want && tries < 60) {
                tries++;
                float cx = towns[t][0] + rr(-34, 34), cz = towns[t][1] + rr(-34, 34);
                if (Math.sqrt(cx * cx + cz * cz) > MR - 22) continue;
                float w = rr(7, 11), d = rr(7, 10);
                if (!free(cx - w / 2, cz - d / 2, 4) || !free(cx + w / 2, cz + d / 2, 4)
                        || !free(cx - w / 2, cz + d / 2, 4) || !free(cx + w / 2, cz - d / 2, 4)) continue;
                house(cx, cz, w, d);
                made++;
            }
        }

        // containers
        int[] cc = { 0xc0392b, 0x2980b9, 0xe67e22, 0x27ae60 };
        for (int i = 0, n = 0; i < 80 && n < 16; i++) {
            float x = rr(-MR + 20, MR - 20), z = rr(-MR + 20, MR - 20);
            if (Math.sqrt(x * x + z * z) > MR - 20 || !free(x, z, 6)) continue;
            boolean alongX = rnd.nextBoolean();
            float sx = alongX ? 6f : 2.4f, sz = alongX ? 2.4f : 6f;
            solid(x, 0, z, sx, 2.6f, sz, cc[rnd.nextInt(cc.length)]);
            rects.add(new float[] { x - sx / 2, z - sz / 2, x + sx / 2, z + sz / 2 });
            lootSpots.add(new float[] { x + (alongX ? 0 : 3.2f), z + (alongX ? 3.2f : 0) });
            n++;
        }

        // muros baixos (cobertura)
        for (int i = 0, n = 0; i < 100 && n < 26; i++) {
            float x = rr(-MR + 15, MR - 15), z = rr(-MR + 15, MR - 15);
            if (Math.sqrt(x * x + z * z) > MR - 15 || !free(x, z, 4)) continue;
            boolean alongX = rnd.nextBoolean();
            solid(x, 0, z, alongX ? 4.5f : 0.5f, 1.1f, alongX ? 0.5f : 4.5f, 0x9ca3af);
            n++;
        }

        // caixas pequenas (da pra pular em cima)
        for (int i = 0, n = 0; i < 100 && n < 30; i++) {
            float x = rr(-MR + 10, MR - 10), z = rr(-MR + 10, MR - 10);
            if (Math.sqrt(x * x + z * z) > MR - 10 || !free(x, z, 2)) continue;
            solid(x, 0, z, 1f, 1f, 1f, 0xa16207);
            n++;
        }

        // pedras
        for (int i = 0, n = 0; i < 120 && n < 45; i++) {
            float x = rr(-MR + 8, MR - 8), z = rr(-MR + 8, MR - 8);
            if (Math.sqrt(x * x + z * z) > MR - 8 || !free(x, z, 3)) continue;
            float s = rr(1.4f, 3.2f);
            solid(x, 0, z, s, s * 0.8f, s * 0.9f, 0x8a9099);
            if (rnd.nextBoolean()) deco(x + 0.2f, s * 0.8f, z, s * 0.6f, s * 0.4f, s * 0.6f, 0x9aa1ab);
            if (rnd.nextInt(3) == 0) lootSpots.add(new float[] { x + 2.2f, z });
            n++;
        }

        // arvores
        for (int i = 0, n = 0; i < 700 && n < 280; i++) {
            float x = rr(-MR + 4, MR - 4), z = rr(-MR + 4, MR - 4);
            if (Math.sqrt(x * x + z * z) > MR - 6 || !free(x, z, 2.5f)) continue;
            float th = rr(2.2f, 3.4f), cw = rr(3f, 4.4f);
            int g = GREENS[rnd.nextInt(GREENS.length)];
            solid(x, 0, z, 0.55f, th, 0.55f, 0x6d4c41);
            deco(x, th - 0.4f, z, cw, 1.5f, cw, g);
            deco(x, th + 1.0f, z, cw * 0.65f, 1.3f, cw * 0.65f, GREENS[(rnd.nextInt(GREENS.length))]);
            n++;
        }

        // pontos extras de loot ao ar livre
        for (int i = 0, n = 0; i < 200 && n < 40; i++) {
            float x = rr(-MR + 10, MR - 10), z = rr(-MR + 10, MR - 10);
            if (Math.sqrt(x * x + z * z) > MR - 12 || !free(x, z, 1.5f)) continue;
            lootSpots.add(new float[] { x, z });
            n++;
        }

        // nuvens
        for (int i = 0; i < 24; i++) {
            float x = rr(-350, 350), z = rr(-350, 350), y = rr(85, 105);
            deco(x, y, z, rr(14, 26), 3, rr(8, 14), 0xffffff);
            deco(x + 4, y + 2.5f, z + 1, rr(8, 14), 2.5f, rr(6, 10), 0xf8fafc);
        }
    }

    void house(float cx, float cz, float w, float d) {
        float h = 3.4f, t = 0.4f;
        int wc = WALLS[rnd.nextInt(WALLS.length)];
        int rc = ROOFS[rnd.nextInt(ROOFS.length)];
        int door = rnd.nextInt(4); // 0 N,1 S,2 L,3 O
        deco(cx, 0f, cz, w, 0.08f, d, 0xc8a977);
        wallX(cx, cz - d / 2, w, t, h, wc, door == 0);
        wallX(cx, cz + d / 2, w, t, h, wc, door == 1);
        wallZ(cx - w / 2, cz, d, t, h, wc, door == 2);
        wallZ(cx + w / 2, cz, d, t, h, wc, door == 3);
        solid(cx, h, cz, w + 0.8f, 0.3f, d + 0.8f, rc);
        solid(cx + w / 2 - 1.2f, 0, cz - d / 2 + 1.5f, 1f, 1f, 1f, 0xa16207);
        rects.add(new float[] { cx - w / 2, cz - d / 2, cx + w / 2, cz + d / 2 });
        int n = 1 + rnd.nextInt(2);
        for (int i = 0; i < n; i++)
            lootSpots.add(new float[] { cx + rr(-w / 3, w / 3), cz + rr(-d / 3, d / 3) });
    }

    void wallX(float cx, float z, float len, float t, float h, int col, boolean door) {
        if (!door) {
            solid(cx, 0, z, len, h, t, col);
            deco(cx - len / 4, 1.2f, z - t / 2 - 0.02f, 1.2f, 1f, 0.05f, 0x9ad7ff);
            deco(cx + len / 4, 1.2f, z + t / 2 + 0.02f, 1.2f, 1f, 0.05f, 0x9ad7ff);
        } else {
            float gap = 2.4f, side = (len - gap) / 2;
            solid(cx - gap / 2 - side / 2, 0, z, side, h, t, col);
            solid(cx + gap / 2 + side / 2, 0, z, side, h, t, col);
            solid(cx, 2.3f, z, gap, h - 2.3f, t, col);
        }
    }

    void wallZ(float x, float cz, float len, float t, float h, int col, boolean door) {
        if (!door) {
            solid(x, 0, cz, t, h, len, col);
            deco(x - t / 2 - 0.02f, 1.2f, cz, 0.05f, 1f, 1.2f, 0x9ad7ff);
        } else {
            float gap = 2.4f, side = (len - gap) / 2;
            solid(x, 0, cz - gap / 2 - side / 2, t, h, side, col);
            solid(x, 0, cz + gap / 2 + side / 2, t, h, side, col);
            solid(x, 2.3f, cz, t, h - 2.3f, gap, col);
        }
    }

    // ------------------------------------------------------------- fisica

    /** Empurra o personagem para fora das paredes (circulo contra caixa). */
    public void resolve(Entity e, float r) {
        float top = e.y + e.height();
        int ci = cell(e.x), cj = cell(e.z);
        for (int di = -1; di <= 1; di++) {
            for (int dj = -1; dj <= 1; dj++) {
                int i = ci + di, j = cj + dj;
                if (i < 0 || j < 0 || i >= GN || j >= GN) continue;
                ArrayList<Box> l = grid[i * GN + j];
                for (int k = 0; k < l.size(); k++) {
                    Box b = l.get(k);
                    if (e.y >= b.y1 - 0.36f) continue;
                    if (top <= b.y0) continue;
                    float px = e.x < b.x0 ? b.x0 : (e.x > b.x1 ? b.x1 : e.x);
                    float pz = e.z < b.z0 ? b.z0 : (e.z > b.z1 ? b.z1 : e.z);
                    float dx = e.x - px, dz = e.z - pz;
                    float d2 = dx * dx + dz * dz;
                    if (d2 < r * r) {
                        if (d2 > 1e-6f) {
                            float dd = (float) Math.sqrt(d2), push = r - dd;
                            e.x += dx / dd * push;
                            e.z += dz / dd * push;
                        } else {
                            float l0 = e.x - b.x0, r0 = b.x1 - e.x, t0 = e.z - b.z0, b0 = b.z1 - e.z;
                            float m = Math.min(Math.min(l0, r0), Math.min(t0, b0));
                            if (m == l0) e.x = b.x0 - r;
                            else if (m == r0) e.x = b.x1 + r;
                            else if (m == t0) e.z = b.z0 - r;
                            else e.z = b.z1 + r;
                        }
                    }
                }
            }
        }
    }

    /** Altura do chao (ou do topo de uma caixa) sob o personagem. */
    public float groundAt(float x, float z, float y) {
        float g = 0f;
        ArrayList<Box> l = grid[cell(x) * GN + cell(z)];
        for (int k = 0; k < l.size(); k++) {
            Box b = l.get(k);
            if (x >= b.x0 - 0.2f && x <= b.x1 + 0.2f && z >= b.z0 - 0.2f && z <= b.z1 + 0.2f
                    && b.y1 <= y + 0.36f && b.y1 > g) g = b.y1;
        }
        return g;
    }

    /** Raio contra o mundo. Retorna a distancia do primeiro impacto (ou maxT). */
    public float raycast(float ox, float oy, float oz, float dx, float dy, float dz, float maxT) {
        float best = maxT;
        if (dy < -1e-5f) {
            float tg = -oy / dy;
            if (tg > 0 && tg < best) best = tg;
        }
        stampN++;
        float step = 8f;
        for (float s = 0; s <= best + step; s += step) {
            float px = ox + dx * s, pz = oz + dz * s;
            int i = cell(px), j = cell(pz);
            for (int di = -1; di <= 1; di++) {
                for (int dj = -1; dj <= 1; dj++) {
                    int ii = i + di, jj = j + dj;
                    if (ii < 0 || jj < 0 || ii >= GN || jj >= GN) continue;
                    ArrayList<Box> l = grid[ii * GN + jj];
                    for (int k = 0; k < l.size(); k++) {
                        Box b = l.get(k);
                        if (b.stamp == stampN) continue;
                        b.stamp = stampN;
                        float t = rayBox(ox, oy, oz, dx, dy, dz, b, best);
                        if (t >= 0 && t < best) best = t;
                    }
                }
            }
        }
        return best;
    }

    static float rayBox(float ox, float oy, float oz, float dx, float dy, float dz, Box b, float maxT) {
        float tmin = 0f, tmax = maxT;
        float[] o = { ox, oy, oz }, d = { dx, dy, dz };
        float[] lo = { b.x0, b.y0, b.z0 }, hi = { b.x1, b.y1, b.z1 };
        for (int a = 0; a < 3; a++) {
            if (Math.abs(d[a]) < 1e-7f) {
                if (o[a] < lo[a] || o[a] > hi[a]) return -1f;
            } else {
                float inv = 1f / d[a];
                float t1 = (lo[a] - o[a]) * inv, t2 = (hi[a] - o[a]) * inv;
                if (t1 > t2) { float tt = t1; t1 = t2; t2 = tt; }
                if (t1 > tmin) tmin = t1;
                if (t2 < tmax) tmax = t2;
                if (tmin > tmax) return -1f;
            }
        }
        return tmin;
    }
}
