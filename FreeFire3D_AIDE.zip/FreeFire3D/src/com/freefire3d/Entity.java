package com.freefire3d;

/** Jogador ou bot. */
public class Entity {
    public float x, y, z, vy, yaw, pitch;
    public float hp = 100f, armor = 0f;
    public boolean alive = true, onGround = true, crouch = false, isPlayer = false;
    public boolean active = true;      // false = ainda dentro do aviao
    public boolean landed = true;
    public int[] slot = { -1, -1, Wpn.KATANA };
    public int[] ammo = new int[3];
    public int cur = 2;
    public int medkits = 0;
    public float fireCd = 0f, reloadT = 0f, healT = 0f, hitFlash = 0f;
    public boolean reloading = false;
    public int kills = 0;
    public String name = "Bot";
    public int shirt = 0x2563eb;
    public float walk = 0f, speed = 0f;
    public boolean chute = false;

    public float height() { return crouch ? 1.3f : 1.8f; }
    public float eye() { return y + (crouch ? 1.15f : 1.65f); }
    public Wpn gun() { int w = slot[cur]; return w < 0 ? null : Wpn.ALL[w]; }
}
