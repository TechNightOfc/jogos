package com.freefire3d;

/** Botoes, joystick, minimapa, barras e textos. */
public class Hud {
    static class Btn {
        int id; float cx, cy, r, w, h; boolean rect; String label; int color;
        Btn(int id, float cx, float cy, float r, String label, int color) {
            this.id = id; this.cx = cx; this.cy = cy; this.r = r; this.label = label; this.color = color;
        }
        Btn(int id, float cx, float cy, float w, float h, String label, int color) {
            this.id = id; this.cx = cx; this.cy = cy; this.w = w; this.h = h; this.rect = true;
            this.label = label; this.color = color;
        }
    }

    Btn[] btns = new Btn[0];
    public float u = 10f, W = 800, H = 400;
    public float stickOX, stickOY, stickKX, stickKY;
    public boolean stickOn;

    public void layout(int w, int h) {
        W = w; H = h; u = h / 100f;
        btns = new Btn[] {
            new Btn(Input.B_FIRE, w - 20 * u, h - 30 * u, 11 * u, "FOGO", 0xef4444),
            new Btn(Input.B_AIM, w - 38 * u, h - 14 * u, 7 * u, "MIRA", 0x38bdf8),
            new Btn(Input.B_JUMP, w - 13 * u, h - 10 * u, 7 * u, "PULO", 0xfacc15),
            new Btn(Input.B_CROUCH, w - 52 * u, h - 27 * u, 6 * u, "AGACH", 0xa78bfa),
            new Btn(Input.B_RELOAD, w - 12 * u, h - 52 * u, 6 * u, "RECAR", 0xfb923c),
            new Btn(Input.B_MEDKIT, w - 26 * u, h - 52 * u, 6 * u, "+", 0x22c55e),
            new Btn(Input.B_PICKUP, w / 2f, h - 30 * u, 7 * u, "PEGAR", 0xfde047),
            new Btn(Input.B_S0, w - 40 * u, 6 * u, 13 * u, 7 * u, "", 0x1f2937),
            new Btn(Input.B_S1, w - 25 * u, 6 * u, 13 * u, 7 * u, "", 0x1f2937),
            new Btn(Input.B_S2, w - 10 * u, 6 * u, 13 * u, 7 * u, "", 0x1f2937),
            new Btn(Input.B_START, w * 0.74f, h * 0.80f, 44 * u, 15 * u, "INICIAR", 0xf97316),
            new Btn(Input.B_PLANEJUMP, w / 2f, h - 20 * u, 38 * u, 12 * u, "PULAR", 0xf97316),
            new Btn(Input.B_LOBBY, w / 2f, h * 0.74f, 46 * u, 12 * u, "VOLTAR AO LOBBY", 0x2563eb)
        };
    }

    boolean visible(Btn b, Game g) {
        int ph = g.phase;
        switch (b.id) {
            case Input.B_START: return ph == Game.LOBBY;
            case Input.B_PLANEJUMP: return ph == Game.PLANE;
            case Input.B_LOBBY: return ph == Game.DEAD || ph == Game.WIN;
            case Input.B_PICKUP: return ph == Game.PLAY && g.pl != null && g.pl.alive && g.near != null;
            default: return ph == Game.PLAY && g.pl != null && g.pl.alive;
        }
    }

    /** Retorna o id do botao tocado ou -1. */
    public int hit(float x, float y, Game g) {
        for (int i = btns.length - 1; i >= 0; i--) {
            Btn b = btns[i];
            if (!visible(b, g)) continue;
            if (b.rect) {
                if (Math.abs(x - b.cx) <= b.w / 2 && Math.abs(y - b.cy) <= b.h / 2) return b.id;
            } else {
                float dx = x - b.cx, dy = y - b.cy, rr = b.r * 1.2f;
                if (dx * dx + dy * dy <= rr * rr) return b.id;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------- desenho

    public void drawLobbyBg() {
        int n = 10;
        for (int i = 0; i < n; i++) {
            float f = i / (float) (n - 1);
            int r = (int) (0x12 + (0x4a - 0x12) * f), g = (int) (0x18 + (0x1d - 0x18) * f), b = (int) (0x38 + (0x5e - 0x38) * f);
            Gfx.rect(0, H * i / n, W, H / n + 2, (r << 16) | (g << 8) | b, 1f);
        }
    }

    void button(Btn b, boolean on, Game g) {
        if (b.rect) {
            Gfx.rect(b.cx - b.w / 2, b.cy - b.h / 2, b.w, b.h, b.color, on ? 0.95f : 0.75f);
            Gfx.rect(b.cx - b.w / 2, b.cy - b.h / 2, b.w, 0.35f * u, 0xffffff, 0.35f);
            Gfx.text(b.label, b.cx, b.cy, b.h * 0.46f, 0xffffff, 1, 1f);
        } else {
            Gfx.circle(b.cx, b.cy, b.r, b.color, on ? 0.7f : 0.32f);
            Gfx.ring(b.cx, b.cy, b.r - 0.35f * u, b.r, 0xffffff, 0.75f);
            Gfx.text(b.label, b.cx, b.cy, b.r * 0.42f, 0xffffff, 1, 1f);
        }
    }

    public void drawLobby(Game g, Input in) {
        Gfx.text("FREE FIRE 3D", W * 0.74f, 15 * u, 11 * u, 0xfacc15, 1, 1f);
        Gfx.text("BATTLE ROYALE  -  BERMUDAS", W * 0.74f, 26 * u, 4 * u, 0xffffff, 1, 1f);
        Gfx.rect(W * 0.74f - 24 * u, 36 * u, 48 * u, 22 * u, 0x000000, 0.35f);
        Gfx.text("Jogador: Voce", W * 0.74f, 41 * u, 3.8f * u, 0xffffff, 1, 1f);
        Gfx.text("Nivel 1  |  Rank Bronze", W * 0.74f, 47 * u, 3.4f * u, 0x93c5fd, 1, 1f);
        Gfx.text("Moedas 1200    Diamantes 0", W * 0.74f, 53 * u, 3.4f * u, 0xfde68a, 1, 1f);
        Gfx.text("Modo: Solo - 30 jogadores", W * 0.74f, 66 * u, 3.6f * u, 0xcbd5e1, 1, 1f);
        for (int i = 0; i < btns.length; i++) if (visible(btns[i], g)) button(btns[i], false, g);
        Gfx.text("Mapa 190m  |  Zona fecha em 5 fases", W * 0.74f, 94 * u, 3f * u, 0x94a3b8, 1, 1f);
    }

    void minimap(Game g) {
        float R = 13 * u, mx = 16.5f * u, my = 17 * u, s = R / (World.MR + 10f);
        Gfx.circle(mx, my, R, 0x0b1220, 0.55f);
        Gfx.ring(mx, my, World.MR * s - 0.3f * u, World.MR * s, 0x4ade80, 0.55f);
        if (g.gasOn) {
            Gfx.ring(mx + g.gasX * s, my + g.gasZ * s, Math.max(0f, g.gasR * s - 0.3f * u), g.gasR * s + 0.3f * u, 0xffffff, 0.95f);
            if (g.gasShrink)
                Gfx.ring(mx + g.gTX * s, my + g.gTZ * s, Math.max(0f, g.gTR * s - 0.25f * u), g.gTR * s + 0.25f * u, 0x38bdf8, 0.9f);
        }
        if (g.phase == Game.PLANE) {
            Gfx.circle(mx + g.planeX * s, my + g.planeZ * s, 1.4f * u, 0xfacc15, 1f);
        }
        if (g.pl != null) {
            for (int i = 0; i < g.ents.size(); i++) {
                Entity e = g.ents.get(i);
                if (e == g.pl || !e.alive || !e.active || !e.landed) continue;
                float dx = e.x - g.pl.x, dz = e.z - g.pl.z;
                if (dx * dx + dz * dz < 45f * 45f) Gfx.circle(mx + e.x * s, my + e.z * s, 0.8f * u, 0xef4444, 1f);
            }
            if (g.phase != Game.PLANE) {
                float px = mx + g.pl.x * s, py = my + g.pl.z * s;
                float fx = (float) Math.sin(g.pl.yaw), fz = -(float) Math.cos(g.pl.yaw);
                Gfx.line(px, py, px + fx * 2.6f * u, py + fz * 2.6f * u, 0.5f * u, 0xffffff, 1f);
                Gfx.circle(px, py, 1.1f * u, 0x38bdf8, 1f);
            }
        }
        Gfx.ring(mx, my, R - 0.3f * u, R, 0xffffff, 0.8f);
    }

    void stick() {
        float bx = stickOn ? stickOX : 20 * u, by = stickOn ? stickOY : H - 24 * u;
        Gfx.circle(bx, by, 10 * u, 0xffffff, 0.12f);
        Gfx.ring(bx, by, 9.6f * u, 10 * u, 0xffffff, 0.5f);
        float kx = stickOn ? stickKX : bx, ky = stickOn ? stickKY : by;
        Gfx.circle(kx, ky, 4.5f * u, 0xffffff, 0.45f);
    }

    public void draw(Game g, Input in) {
        Entity p = g.pl;
        int ph = g.phase;
        boolean alive = p != null && p.alive;
        Wpn w = alive ? p.gun() : null;
        boolean scoped = ph == Game.PLAY && g.aim && !g.thirdPerson && w != null && w.sniper;

        if (scoped) {
            float cx = W / 2f, cy = H / 2f;
            Gfx.ring(cx, cy, H * 0.43f, (float) Math.sqrt(W * W + H * H) / 2f + 20f, 0x000000, 1f);
            Gfx.line(cx - H * 0.43f, cy, cx + H * 0.43f, cy, 0.25f * u, 0x000000, 0.9f);
            Gfx.line(cx, cy - H * 0.43f, cx, cy + H * 0.43f, 0.25f * u, 0x000000, 0.9f);
        }
        if (g.hurt > 0) Gfx.rect(0, 0, W, H, 0xff0000, Math.min(0.4f, g.hurt * 0.5f));
        if (g.playerOutside() && alive) Gfx.rect(0, 0, W, H, 0x7c3aed, 0.14f);

        minimap(g);

        // contadores
        Gfx.rect(W / 2f - 19 * u, 1.5f * u, 38 * u, 6 * u, 0x000000, 0.5f);
        Gfx.text("VIVOS " + g.aliveCount, W / 2f - 1 * u, 4.5f * u, 3.4f * u, 0xffffff, 2, 1f);
        Gfx.text("ABATES " + (p == null ? 0 : p.kills), W / 2f + 1 * u, 4.5f * u, 3.4f * u, 0xfde047, 0, 1f);
        if (ph != Game.LOBBY && ph != Game.WIN) {
            boolean out = g.playerOutside() && alive;
            Gfx.text(out ? "FORA DA ZONA! VOLTE!" : g.gasText(), W / 2f, 11.5f * u, 3.1f * u, out ? 0xc4b5fd : 0xffffff, 1, 1f);
        }
        // kill feed
        for (int i = 0; i < g.feed.size(); i++) {
            Game.Feed f = g.feed.get(i);
            Gfx.text(f.s, W - 3 * u, (17 + i * 4.6f) * u, 2.9f * u, 0xffffff, 2, Math.min(1f, f.t));
        }

        if (ph == Game.PLANE) {
            Gfx.text("VOCE ESTA NO AVIAO", W / 2f, 20 * u, 4.5f * u, 0xffffff, 1, 1f);
            Gfx.text("Toque em PULAR quando quiser", W / 2f, 26 * u, 3.2f * u, 0xfde68a, 1, 1f);
        } else if (ph == Game.FALL) {
            Gfx.text("Use o joystick para planar", W / 2f, 20 * u, 3.6f * u, 0xffffff, 1, 1f);
        }

        if (ph == Game.FALL || (ph == Game.PLAY && alive)) stick();

        if (ph == Game.PLAY && alive) {
            if (!scoped) {
                float cx = W / 2f, cy = H / 2f, a = 1.2f * u, b = 2.6f * u;
                Gfx.line(cx - b, cy, cx - a, cy, 0.25f * u, 0xffffff, 0.9f);
                Gfx.line(cx + a, cy, cx + b, cy, 0.25f * u, 0xffffff, 0.9f);
                Gfx.line(cx, cy - b, cx, cy - a, 0.25f * u, 0xffffff, 0.9f);
                Gfx.line(cx, cy + a, cx, cy + b, 0.25f * u, 0xffffff, 0.9f);
            }
            if (g.hitMark > 0) {
                float cx = W / 2f, cy = H / 2f, a = 1.5f * u, b = 3.2f * u;
                int c = g.hitHead ? 0xef4444 : 0xffffff;
                Gfx.line(cx - b, cy - b, cx - a, cy - a, 0.35f * u, c, 1f);
                Gfx.line(cx + b, cy - b, cx + a, cy - a, 0.35f * u, c, 1f);
                Gfx.line(cx - b, cy + b, cx - a, cy + a, 0.35f * u, c, 1f);
                Gfx.line(cx + b, cy + b, cx + a, cy + a, 0.35f * u, c, 1f);
            }
            // vida / colete
            float bw = 40 * u, bx = W / 2f - bw / 2f, by = H - 9 * u;
            Gfx.rect(bx, by - 3.6f * u, bw, 1.6f * u, 0x000000, 0.5f);
            Gfx.rect(bx, by - 3.6f * u, bw * Math.max(0f, p.armor) / 100f, 1.6f * u, 0x38bdf8, 0.95f);
            Gfx.rect(bx, by, bw, 3.4f * u, 0x000000, 0.55f);
            float hpf = Math.max(0f, p.hp) / 100f;
            Gfx.rect(bx, by, bw * hpf, 3.4f * u, hpf > 0.35f ? 0x22c55e : 0xef4444, 0.95f);
            Gfx.text("HP " + (int) Math.ceil(Math.max(0f, p.hp)), W / 2f, by + 1.7f * u, 2.8f * u, 0xffffff, 1, 1f);

            // municao
            String ammo = (w == null) ? "" : (w.melee ? w.name : w.name + "  " + p.ammo[p.cur] + "/" + w.mag);
            Gfx.text(ammo, W - 4 * u, H - 62 * u, 3.8f * u, 0xffffff, 2, 1f);
            if (p.reloading) Gfx.text("RECARREGANDO...", W - 4 * u, H - 67 * u, 3f * u, 0xfb923c, 2, 1f);
            if (p.healT > 0) Gfx.text("CURANDO...", W - 4 * u, H - 67 * u, 3f * u, 0x4ade80, 2, 1f);
            if (g.near != null) Gfx.text(g.near.label(), W / 2f, H - 40 * u, 3.6f * u, 0xfde047, 1, 1f);
        }

        for (int i = 0; i < btns.length; i++) {
            Btn b = btns[i];
            if (!visible(b, g) || ph == Game.LOBBY) continue;
            boolean on = false;
            if (b.id == Input.B_AIM) on = g.aim;
            else if (b.id == Input.B_CROUCH) on = p != null && p.crouch;
            else if (b.id == Input.B_FIRE) on = in.fire;
            if (b.id >= Input.B_S0 && b.id <= Input.B_S2) {
                int s = b.id - Input.B_S0;
                boolean has = p.slot[s] >= 0;
                boolean cur = p.cur == s;
                Gfx.rect(b.cx - b.w / 2, b.cy - b.h / 2, b.w, b.h, cur ? 0xf97316 : 0x111827, cur ? 0.85f : 0.55f);
                String nm = has ? Wpn.ALL[p.slot[s]].name : "-";
                if (nm.length() > 8) nm = nm.substring(0, 8);
                Gfx.text(nm, b.cx, b.cy, 2.6f * u, has ? 0xffffff : 0x6b7280, 1, 1f);
            } else {
                button(b, on, g);
                if (b.id == Input.B_MEDKIT) Gfx.text("x" + p.medkits, b.cx, b.cy + b.r * 0.62f, b.r * 0.36f, 0xffffff, 1, 1f);
            }
        }

        if (ph == Game.DEAD || ph == Game.WIN) {
            Gfx.rect(0, 0, W, H, 0x000000, 0.5f);
            if (ph == Game.WIN) {
                Gfx.text("BOOYAH!", W / 2f, 28 * u, 15 * u, 0xfacc15, 1, 1f);
                Gfx.text("VOCE VENCEU!", W / 2f, 44 * u, 6 * u, 0xffffff, 1, 1f);
            } else {
                Gfx.text("VOCE FOI ELIMINADO", W / 2f, 26 * u, 8 * u, 0xef4444, 1, 1f);
                Gfx.text("Posicao #" + g.rank, W / 2f, 42 * u, 6 * u, 0xffffff, 1, 1f);
            }
            Gfx.text("Abates: " + (p == null ? 0 : p.kills), W / 2f, 55 * u, 4.5f * u, 0xfde047, 1, 1f);
            for (int i = 0; i < btns.length; i++) if (visible(btns[i], g)) button(btns[i], false, g);
        }
    }
}
